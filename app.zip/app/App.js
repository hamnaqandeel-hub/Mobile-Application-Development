import React, { useState, useEffect, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  SafeAreaView,
  StatusBar,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  Modal,
  ActivityIndicator,
  RefreshControl,
  FlatList,
  Linking,
  Animated,
  Switch
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

// ==============================================
// ✅ FIXED FIREBASE CONFIGURATION
// ==============================================
const PROJECT_ID = "mobile-app-d863d";
const API_KEY = "AIzaSyAhEVEVt01vL4vgnH68hl3wFiU6yn8Q8gw";

// ==============================================
// ✅ IMPROVED FIRESTORE HELPER FUNCTIONS
// ==============================================
const convertToFirestoreFields = (data) => {
  const fields = {};
  Object.keys(data).forEach(key => {
    const value = data[key];
    
    if (value === null || value === undefined) {
      fields[key] = { nullValue: null };
    } else if (typeof value === 'string') {
      fields[key] = { stringValue: value };
    } else if (typeof value === 'boolean') {
      fields[key] = { booleanValue: value };
    } else if (typeof value === 'number') {
      if (Number.isInteger(value)) {
        fields[key] = { integerValue: value.toString() };
      } else {
        fields[key] = { doubleValue: value };
      }
    } else if (Array.isArray(value)) {
      fields[key] = { 
        arrayValue: { 
          values: value.map(item => {
            if (item === null || item === undefined) return { nullValue: null };
            if (typeof item === 'string') return { stringValue: item };
            if (typeof item === 'number') {
              if (Number.isInteger(item)) {
                return { integerValue: item.toString() };
              } else {
                return { doubleValue: item };
              }
            }
            if (typeof item === 'boolean') return { booleanValue: item };
            if (item instanceof Date) return { timestampValue: item.toISOString() };
            if (typeof item === 'object') {
              return { mapValue: { fields: convertToFirestoreFields(item) } };
            }
            return { stringValue: String(item) };
          })
        }
      };
    } else if (value instanceof Date) {
      fields[key] = { timestampValue: value.toISOString() };
    } else if (typeof value === 'object') {
      fields[key] = { mapValue: { fields: convertToFirestoreFields(value) } };
    } else {
      fields[key] = { stringValue: String(value) };
    }
  });
  return fields;
};

const convertFromFirestore = (doc) => {
  const fields = {};
  if (doc.fields) {
    Object.keys(doc.fields).forEach(key => {
      const field = doc.fields[key];
      if (field.stringValue !== undefined) fields[key] = field.stringValue;
      else if (field.integerValue !== undefined) fields[key] = parseInt(field.integerValue, 10);
      else if (field.doubleValue !== undefined) fields[key] = parseFloat(field.doubleValue);
      else if (field.booleanValue !== undefined) fields[key] = field.booleanValue;
      else if (field.timestampValue !== undefined) fields[key] = field.timestampValue;
      else if (field.arrayValue !== undefined && field.arrayValue.values) {
        fields[key] = field.arrayValue.values.map(v => {
          if (v.stringValue !== undefined) return v.stringValue;
          if (v.integerValue !== undefined) return parseInt(v.integerValue, 10);
          if (v.doubleValue !== undefined) return parseFloat(v.doubleValue);
          if (v.booleanValue !== undefined) return v.booleanValue;
          if (v.timestampValue !== undefined) return v.timestampValue;
          if (v.mapValue !== undefined) return convertFromFirestore(v.mapValue);
          if (v.nullValue !== undefined) return null;
          return null;
        });
      } else if (field.mapValue !== undefined) {
        fields[key] = convertFromFirestore(field.mapValue);
      } else if (field.nullValue !== undefined) {
        fields[key] = null;
      }
    });
  }
  const id = doc.name ? doc.name.split('/').pop() : null;
  return { id, ...fields };
};

// ==============================================
// ✅ IMPROVED FIRESTORE OPERATIONS
// ==============================================
const saveToFirestore = async (collection, data, documentId = null) => {
  try {
    let url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/${collection}`;
    
    if (documentId) {
      url += `/${documentId}`;
    }
    
    const method = documentId ? 'PATCH' : 'POST';
    const firestoreData = convertToFirestoreFields(data);
    
    const requestBody = {
      fields: firestoreData
    };
    
    // For PATCH requests, add updateMask
    if (method === 'PATCH') {
      requestBody.updateMask = {
        fieldPaths: Object.keys(firestoreData)
      };
    }
    
    console.log('Saving to Firestore:', { collection, documentId, method, data: firestoreData });
    
    const response = await fetch(url, {
      method: method,
      headers: { 
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody)
    });
    
    const result = await response.json();
    
    if (!response.ok) {
      console.error('Firestore save error:', result);
      return { 
        success: false, 
        error: result.error?.message || JSON.stringify(result.error) || 'Save failed' 
      };
    }
    
    const id = result.name?.split('/').pop() || documentId;
    return { success: true, id, data: result };
    
  } catch (error) {
    console.error('Save to Firestore failed:', error);
    return { success: false, error: error.message };
  }
};

const fetchFromFirestore = async (collection, filters = [], limit = null) => {
  try {
    let url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/${collection}`;
    
    const params = new URLSearchParams();
    
    // Add filters if provided
    if (filters.length > 0) {
      const structuredQuery = {
        where: {
          compositeFilter: {
            op: 'AND',
            filters: filters.map(filter => ({
              fieldFilter: {
                field: { fieldPath: filter.field },
                op: filter.op || 'EQUAL',
                value: { [filter.valueType || 'stringValue']: filter.value }
              }
            }))
          }
        }
      };
      
      // For single filter, use simple where
      if (filters.length === 1) {
        const filter = filters[0];
        structuredQuery.where = {
          fieldFilter: {
            field: { fieldPath: filter.field },
            op: filter.op || 'EQUAL',
            value: { [filter.valueType || 'stringValue']: filter.value }
          }
        };
      }
      
      params.append('structuredQuery', JSON.stringify(structuredQuery));
    }
    
    if (limit) {
      params.append('pageSize', limit.toString());
    }
    
    if (params.toString()) {
      url += `?${params.toString()}`;
    }
    
    console.log('Fetching from Firestore:', url);
    
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
      }
    });
    
    const result = await response.json();
    
    if (!response.ok) {
      console.error('Firestore fetch error:', result);
      return { 
        success: false, 
        error: result.error?.message || JSON.stringify(result.error) || 'Fetch failed' 
      };
    }
    
    const documents = result.documents 
      ? result.documents.map(doc => convertFromFirestore(doc))
      : [];
    
    return { success: true, data: documents };
    
  } catch (error) {
    console.error('Fetch from Firestore failed:', error);
    return { success: false, error: error.message };
  }
};

const deleteFromFirestore = async (collection, documentId) => {
  try {
    const url = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents/${collection}/${documentId}`;
    
    console.log('Deleting from Firestore:', url);
    
    const response = await fetch(url, { 
      method: 'DELETE',
    });
    
    if (!response.ok) {
      const result = await response.json();
      console.error('Firestore delete error:', result);
      return { 
        success: false, 
        error: result.error?.message || JSON.stringify(result.error) || 'Delete failed' 
      };
    }
    
    return { success: true };
    
  } catch (error) {
    console.error('Delete from Firestore failed:', error);
    return { success: false, error: error.message };
  }
};

// ==============================================
//  FIXED FIREBASE AUTHENTICATION
// ==============================================
const authenticateTeacher = async (email, password) => {
  try {
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${API_KEY}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          password: password,
          returnSecureToken: true,
        }),
      }
    );

    const result = await response.json();

    if (response.ok) {
      return {
        success: true,
        user: {
          id: result.localId,
          name: "Mam Nausheen Saba",
          email: email,
          role: "teacher",
          department: "Computer Science",
          avatar: "👩‍🏫",
          token: result.idToken
        }
      };
    } else {
      console.error('Auth error:', result);
      return { 
        success: false, 
        error: result.error?.message || 'Authentication failed. Please check credentials.' 
      };
    }
  } catch (error) {
    console.error('Auth network error:', error);
    return { success: false, error: 'Network error. Please try again.' };
  }
};

// ==============================================
// ✅ HELPER FUNCTIONS
// ==============================================
const getMaterialIcon = (type) => {
  switch (type?.toLowerCase()) {
    case 'lecture': return 'videocam';
    case 'pdf': return 'document-text';
    case 'slides': return 'easel';
    case 'assignment': return 'create';
    case 'code': return 'code';
    case 'video': return 'play-circle';
    case 'quiz': return 'help-circle';
    default: return 'document';
  }
};

const getMaterialColor = (type) => {
  switch (type?.toLowerCase()) {
    case 'lecture': return '#4dc3ff';
    case 'pdf': return '#ff6666';
    case 'slides': return '#33cc33';
    case 'assignment': return '#ff9966';
    case 'code': return '#9966ff';
    case 'video': return '#ff6b93';
    case 'quiz': return '#ffcc00';
    default: return '#666';
  }
};

const calculateGrade = (marks, totalMarks) => {
  const percentage = (marks / totalMarks) * 100;
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B';
  if (percentage >= 60) return 'C';
  if (percentage >= 50) return 'D';
  return 'F';
};

// ==============================================
//  NOTIFICATIONS MODAL
// ==============================================
const NotificationsModal = ({ 
  visible, 
  notifications, 
  onClose, 
  onMarkAsRead,
  onMarkAllAsRead,
  onDeleteAll 
}) => {
  const handleNotificationPress = async (notification) => {
    // Mark as read when tapped
    if (onMarkAsRead && !notification.read) {
      await onMarkAsRead(notification.id);
    }
    
    Alert.alert(notification.title || 'Notification', notification.message || 'No message');
  };

  const handleMarkAllRead = async () => {
    if (onMarkAllAsRead) {
      await onMarkAllAsRead();
    }
    Alert.alert('Success', 'All notifications marked as read');
  };

  const handleDeleteAll = async () => {
    if (onDeleteAll) {
      await onDeleteAll();
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.notificationsModalOverlay}>
        <View style={styles.notificationsModalContent}>
          <View style={styles.notificationsModalHeader}>
            <Text style={styles.notificationsModalTitle}>
              Notifications ({notifications.length})
            </Text>
            <TouchableOpacity onPress={onClose}>
              <Ionicons name="close" size={24} color="#ff6b93" />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.notificationsList}>
            {notifications.length === 0 ? (
              <View style={styles.emptyNotifications}>
                <Ionicons name="notifications-off" size={60} color="#ddd" />
                <Text style={styles.emptyNotificationsText}>No notifications</Text>
                <Text style={styles.emptyNotificationsSubtext}>You're all caught up!</Text>
              </View>
            ) : (
              notifications.map((notification, index) => (
                <TouchableOpacity 
                  key={notification.id || index} 
                  style={[
                    styles.notificationItem,
                    !notification.read && styles.notificationUnread
                  ]}
                  onPress={() => handleNotificationPress(notification)}
                >
                  <View style={styles.notificationIcon}>
                    <Ionicons 
                      name="notifications" 
                      size={22} 
                      color={notification.read ? "#aaa" : "#ff6b93"} 
                    />
                  </View>
                  <View style={styles.notificationContent}>
                    <Text style={[
                      styles.notificationTitle,
                      !notification.read && styles.notificationTitleUnread
                    ]}>
                      {notification.title || 'Notification'}
                    </Text>
                    <Text style={styles.notificationMessage} numberOfLines={2}>
                      {notification.message || 'No message'}
                    </Text>
                    <View style={styles.notificationMeta}>
                      <Text style={styles.notificationType}>
                        {notification.type || 'general'}
                      </Text>
                      <Text style={styles.notificationTime}>
                        {notification.timestamp ? new Date(notification.timestamp).toLocaleDateString() : 'Recently'}
                      </Text>
                    </View>
                  </View>
                  {!notification.read && <View style={styles.unreadDot} />}
                </TouchableOpacity>
              ))
            )}
          </ScrollView>
          
          <View style={styles.notificationsModalFooter}>
            {notifications.length > 0 && (
              <>
                <TouchableOpacity 
                  style={styles.markAllReadButton}
                  onPress={handleMarkAllRead}
                >
                  <Ionicons name="checkmark-done" size={18} color="#33cc33" />
                  <Text style={styles.markAllReadText}>Mark All as Read</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={styles.deleteAllButton}
                  onPress={handleDeleteAll}
                >
                  <Ionicons name="trash" size={18} color="#ff4757" />
                  <Text style={styles.deleteAllText}>Clear All</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
};

// ==============================================
// ✅ COURSE DETAILS PAGE
// ==============================================
const CourseDetailsPage = ({ course, materials, notifications, announcements, assignments, onBack, onOpenMaterial, onSubmitAssignment, studentId }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [downloading, setDownloading] = useState(false);
  const [submittingAssignment, setSubmittingAssignment] = useState(null);

  const courseMaterials = materials.filter(m => m.courseCode === course.code);
  const courseNotifications = notifications.filter(n => n.courseCode === course.code || n.courseCode === 'all');
  const courseAnnouncements = announcements.filter(a => a.courseCode === course.code || a.courseCode === 'all');
  const courseAssignments = assignments.filter(a => a.courseCode === course.code);

  const handleOpenLink = async (url) => {
    try {
      if (!url) {
        Alert.alert('Error', 'No URL available');
        return;
      }
      
      // Ensure URL has proper protocol
      let formattedUrl = url;
      if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
        formattedUrl = 'https://' + formattedUrl;
      }
      
      const supported = await Linking.canOpenURL(formattedUrl);
      if (supported) {
        await Linking.openURL(formattedUrl);
      } else {
        Alert.alert('Error', `Cannot open URL: ${formattedUrl}`);
      }
    } catch (error) {
      console.error('Error opening URL:', error);
      Alert.alert('Error', 'Failed to open link');
    }
  };

  const handleDownload = async (material) => {
    if (!material.fileUrl) {
      Alert.alert('Info', 'No file URL available for this material');
      return;
    }
    
    setDownloading(true);
    try {
      await handleOpenLink(material.fileUrl);
      
      // Update download count
      if (onOpenMaterial && material.id) {
        await onOpenMaterial(material.id);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to download file');
    } finally {
      setDownloading(false);
    }
  };

  const handleSubmitAssignment = async (assignment) => {
    setSubmittingAssignment(assignment.id);
    
    Alert.prompt(
      'Submit Assignment',
      'Enter your submission (URL, text, or description):',
      [
        { text: 'Cancel', style: 'cancel', onPress: () => setSubmittingAssignment(null) },
        { 
          text: 'Submit', 
          onPress: async (submissionText) => {
            if (!submissionText || submissionText.trim() === '') {
              Alert.alert('Error', 'Please enter your submission');
              setSubmittingAssignment(null);
              return;
            }
            
            const submissionData = {
              assignmentId: assignment.id,
              studentId: studentId,
              submission: submissionText.trim(),
              submittedAt: new Date().toISOString(),
              graded: false
            };
            
            if (onSubmitAssignment) {
              const result = await onSubmitAssignment(submissionData);
              if (result.success) {
                Alert.alert('Success', 'Assignment submitted successfully!');
              } else {
                Alert.alert('Error', result.error || 'Failed to submit assignment');
              }
            }
            setSubmittingAssignment(null);
          }
        }
      ],
      'plain-text',
      '',
      'default'
    );
  };

  const renderOverview = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.courseInfoCard}>
        <View style={styles.courseHeaderInfo}>
          <View style={styles.courseCodeCircle}>
            <Text style={styles.courseCodeChar}>{course.code?.charAt(0) || 'C'}</Text>
          </View>
          <View style={styles.courseTitleContainer}>
            <Text style={styles.courseDetailName}>{course.name || 'Course Name'}</Text>
            <Text style={styles.courseDetailCode}>{course.code || 'CODE'} • {course.credits || 3} Credits</Text>
          </View>
        </View>
        
        <View style={styles.courseStats}>
          <View style={styles.statItemDetail}>
            <Ionicons name="person" size={20} color="#4dc3ff" />
            <View style={styles.statItemDetailContent}>
              <Text style={styles.statLabelDetail}>Instructor</Text>
              <Text style={styles.statValueDetail}>{course.teacherName || 'Instructor'}</Text>
            </View>
          </View>
          <View style={styles.statItemDetail}>
            <Ionicons name="time" size={20} color="#ff9966" />
            <View style={styles.statItemDetailContent}>
              <Text style={styles.statLabelDetail}>Schedule</Text>
              <Text style={styles.statValueDetail}>{course.schedule || 'Not scheduled'}</Text>
            </View>
          </View>
          <View style={styles.statItemDetail}>
            <Ionicons name="calendar" size={20} color="#33cc33" />
            <View style={styles.statItemDetailContent}>
              <Text style={styles.statLabelDetail}>Duration</Text>
              <Text style={styles.statValueDetail}>{course.duration || '16 Weeks'}</Text>
            </View>
          </View>
        </View>

        <View style={styles.courseDescriptionSection}>
          <Text style={styles.sectionTitle}>Course Description</Text>
          <Text style={styles.courseDescription}>{course.description || 'No description available.'}</Text>
        </View>

        <View style={styles.learningOutcomes}>
          <Text style={styles.sectionTitle}>Learning Outcomes</Text>
          {course.outcomes ? (
            (Array.isArray(course.outcomes) ? course.outcomes : course.outcomes.split(',')).map((outcome, index) => (
              <View key={index} style={styles.outcomeItem}>
                <Ionicons name="checkmark-circle" size={16} color="#33cc33" />
                <Text style={styles.outcomeText}>{typeof outcome === 'string' ? outcome.trim() : outcome}</Text>
              </View>
            ))
          ) : (
            <Text style={styles.noDataText}>No learning outcomes specified</Text>
          )}
        </View>
      </View>
    </ScrollView>
  );

  const renderMaterials = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.sectionHeaderWithActions}>
        <Text style={styles.sectionTitle}>Course Materials ({courseMaterials.length})</Text>
        <View style={styles.filterButtonsRow}>
          <TouchableOpacity style={[styles.filterButtonStyle, styles.filterButtonActive]}>
            <Text style={styles.filterButtonTextStyle}>All</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterButtonStyle}>
            <Text style={styles.filterButtonTextStyle}>Lectures</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.filterButtonStyle}>
            <Text style={styles.filterButtonTextStyle}>PDFs</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {courseMaterials.length === 0 ? (
        <View style={styles.emptyStateCard}>
          <Ionicons name="document" size={60} color="#ddd" />
          <Text style={styles.emptyStateText}>No materials available</Text>
          <Text style={styles.emptyStateSubtext}>Course materials will be uploaded by the instructor</Text>
        </View>
      ) : (
        courseMaterials.map((material, index) => (
          <TouchableOpacity 
            key={material.id || index} 
            style={styles.materialCard}
            onPress={() => setSelectedMaterial(material)}
          >
            <View style={styles.materialIconContainer}>
              <Ionicons 
                name={getMaterialIcon(material.type)} 
                size={24} 
                color={getMaterialColor(material.type)} 
              />
            </View>
            <View style={styles.materialInfo}>
              <Text style={styles.materialCardTitle}>{material.title || 'Untitled Material'}</Text>
              <Text style={styles.materialCardDescription} numberOfLines={2}>
                {material.description || 'No description'}
              </Text>
              <View style={styles.materialMeta}>
                <Text style={styles.materialType}>{material.type || 'unknown'}</Text>
                <Text style={styles.materialDate}>{material.uploadDate || 'Unknown date'}</Text>
                {material.fileSize && <Text style={styles.materialSize}>{material.fileSize}</Text>}
              </View>
            </View>
            <TouchableOpacity 
              style={styles.downloadButton}
              onPress={() => handleDownload(material)}
              disabled={downloading}
            >
              {downloading && selectedMaterial?.id === material.id ? (
                <ActivityIndicator size="small" color="#4dc3ff" />
              ) : (
                <Ionicons name="download" size={20} color="#4dc3ff" />
              )}
            </TouchableOpacity>
          </TouchableOpacity>
        ))
      )}
    </ScrollView>
  );

  const renderAssignments = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.sectionHeaderWithActions}>
        <Text style={styles.sectionTitle}>Assignments ({courseAssignments.length})</Text>
        <TouchableOpacity style={styles.viewAllButton}>
          <Text style={styles.viewAllButtonText}>View All</Text>
        </TouchableOpacity>
      </View>
      
      {courseAssignments.length === 0 ? (
        <View style={styles.emptyStateCard}>
          <Ionicons name="create" size={60} color="#ddd" />
          <Text style={styles.emptyStateText}>No assignments yet</Text>
          <Text style={styles.emptyStateSubtext}>Assignments will be posted by the instructor</Text>
        </View>
      ) : (
        courseAssignments.map((assignment, index) => {
          const isSubmitted = assignment.submissions?.some(s => s.studentId === studentId);
          const isOverdue = assignment.dueDate && new Date(assignment.dueDate) < new Date();
          
          return (
            <View key={assignment.id || index} style={styles.assignmentCard}>
              <View style={styles.assignmentCardHeader}>
                <View style={[
                  styles.assignmentStatusBadge,
                  { backgroundColor: isOverdue ? '#ffebee' : '#fff9f0' }
                ]}>
                  <Ionicons 
                    name={isOverdue ? "alert-circle" : "time"} 
                    size={14} 
                    color={isOverdue ? "#ff6666" : "#ff9966"} 
                  />
                  <Text style={[
                    styles.assignmentStatusText,
                    { color: isOverdue ? "#ff6666" : "#ff9966" }
                  ]}>
                    {isOverdue ? 'Overdue' : 'Due Soon'}
                  </Text>
                </View>
                <Text style={styles.assignmentDueDate}>Due: {assignment.dueDate || 'No due date'}</Text>
              </View>
              <Text style={styles.assignmentCardTitle}>{assignment.title || 'Untitled Assignment'}</Text>
              <Text style={styles.assignmentCardDescription}>{assignment.description || 'No description'}</Text>
              <View style={styles.assignmentFooter}>
                <View style={styles.assignmentPoints}>
                  <Ionicons name="trophy" size={16} color="#ff6b93" />
                  <Text style={styles.assignmentPointsText}>{assignment.totalPoints || 100} points</Text>
                </View>
                <TouchableOpacity 
                  style={[
                    styles.submitButton,
                    isSubmitted && styles.submitButtonDisabled
                  ]}
                  onPress={() => !isSubmitted && handleSubmitAssignment(assignment)}
                  disabled={isSubmitted || submittingAssignment === assignment.id}
                >
                  {submittingAssignment === assignment.id ? (
                    <ActivityIndicator size="small" color="white" />
                  ) : (
                    <>
                      <Ionicons name={isSubmitted ? "checkmark" : "paper-plane"} size={16} color="#fff" />
                      <Text style={styles.submitButtonText}>
                        {isSubmitted ? 'Submitted' : 'Submit'}
                      </Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          );
        })
      )}
    </ScrollView>
  );

  const renderAnnouncements = () => (
    <ScrollView showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionTitle}>Announcements ({courseAnnouncements.length})</Text>
      
      {courseAnnouncements.length === 0 ? (
        <View style={styles.emptyStateCard}>
          <Ionicons name="megaphone" size={60} color="#ddd" />
          <Text style={styles.emptyStateText}>No announcements</Text>
          <Text style={styles.emptyStateSubtext}>Check back for updates from your instructor</Text>
        </View>
      ) : (
        courseAnnouncements.map((announcement, index) => (
          <View key={announcement.id || index} style={styles.announcementCard}>
            <View style={styles.announcementHeader}>
              <View style={styles.announcementIcon}>
                <Ionicons name="megaphone" size={20} color="#ff6b93" />
              </View>
              <View style={styles.announcementInfo}>
                <Text style={styles.announcementTitle}>{announcement.title || 'Announcement'}</Text>
                <Text style={styles.announcementMeta}>
                  By {announcement.createdBy || 'Instructor'} • {announcement.date || 'Unknown date'}
                </Text>
              </View>
            </View>
            <Text style={styles.announcementContent}>{announcement.message || 'No content'}</Text>
            {announcement.attachments && announcement.attachments.length > 0 && (
              <View style={styles.announcementAttachments}>
                {announcement.attachments.map((attachment, idx) => (
                  <TouchableOpacity 
                    key={idx} 
                    style={styles.attachmentItem} 
                    onPress={() => handleOpenLink(attachment)}
                  >
                    <Ionicons name="document" size={16} color="#4dc3ff" />
                    <Text style={styles.attachmentText}>{attachment}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>
        ))
      )}
    </ScrollView>
  );

  const renderMaterialModal = () => (
    <Modal
      visible={!!selectedMaterial}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setSelectedMaterial(null)}
    >
      <View style={styles.fullModalOverlay}>
        <View style={styles.fullModalContent}>
          <View style={styles.fullModalHeader}>
            <Text style={styles.fullModalTitle}>Material Details</Text>
            <TouchableOpacity onPress={() => setSelectedMaterial(null)}>
              <Ionicons name="close" size={24} color="#ff6b93" />
            </TouchableOpacity>
          </View>
          
          <ScrollView style={styles.fullModalBody}>
            {selectedMaterial && (
              <>
                <View style={styles.materialDetailHeader}>
                  <View style={styles.materialDetailIcon}>
                    <Ionicons 
                      name={getMaterialIcon(selectedMaterial.type)} 
                      size={40} 
                      color={getMaterialColor(selectedMaterial.type)} 
                    />
                  </View>
                  <Text style={styles.materialDetailTitle}>{selectedMaterial.title || 'Untitled Material'}</Text>
                  <Text style={styles.materialDetailType}>{selectedMaterial.type || 'unknown'}</Text>
                </View>
                
                <View style={styles.materialDetailSection}>
                  <Text style={styles.detailSectionTitle}>Description</Text>
                  <Text style={styles.materialDetailDescription}>{selectedMaterial.description || 'No description'}</Text>
                </View>
                
                <View style={styles.materialDetailSection}>
                  <Text style={styles.detailSectionTitle}>Details</Text>
                  <View style={styles.detailGrid}>
                    <View style={styles.detailItemCard}>
                      <Ionicons name="calendar" size={20} color="#666" />
                      <Text style={styles.detailItemLabel}>Upload Date</Text>
                      <Text style={styles.detailItemValue}>{selectedMaterial.uploadDate || 'Unknown'}</Text>
                    </View>
                    <View style={styles.detailItemCard}>
                      <Ionicons name="person" size={20} color="#666" />
                      <Text style={styles.detailItemLabel}>Uploaded By</Text>
                      <Text style={styles.detailItemValue}>{selectedMaterial.uploadedBy || 'Unknown'}</Text>
                    </View>
                    {selectedMaterial.fileSize && (
                      <View style={styles.detailItemCard}>
                        <Ionicons name="cloud-download" size={20} color="#666" />
                        <Text style={styles.detailItemLabel}>File Size</Text>
                        <Text style={styles.detailItemValue}>{selectedMaterial.fileSize}</Text>
                      </View>
                    )}
                  </View>
                </View>
                
                {selectedMaterial.fileUrl && (
                  <View style={styles.materialDetailSection}>
                    <Text style={styles.detailSectionTitle}>Actions</Text>
                    <TouchableOpacity 
                      style={styles.actionButtonLarge}
                      onPress={() => handleOpenLink(selectedMaterial.fileUrl)}
                    >
                      <Ionicons name="open" size={20} color="white" />
                      <Text style={styles.actionButtonTextLarge}>Open File</Text>
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={[styles.actionButtonLarge, styles.actionButtonSecondary]}
                      onPress={() => handleDownload(selectedMaterial)}
                    >
                      <Ionicons name="download" size={20} color="#4dc3ff" />
                      <Text style={[styles.actionButtonTextLarge, styles.actionButtonTextSecondary]}>
                        Download
                      </Text>
                    </TouchableOpacity>
                  </View>
                )}
              </>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  return (
    <SafeAreaView style={styles.courseDetailsContainer}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <View style={styles.courseDetailsHeader}>
        <TouchableOpacity style={styles.backButton} onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color="#ff6b93" />
        </TouchableOpacity>
        <View style={styles.courseDetailsHeaderCenter}>
          <Text style={styles.courseDetailsHeaderTitle} numberOfLines={1}>
            {course.code || 'Course'}
          </Text>
          <Text style={styles.courseDetailsHeaderSubtitle} numberOfLines={1}>
            {course.name || 'Course Name'}
          </Text>
        </View>
        <TouchableOpacity style={styles.headerActionButton}>
          <Ionicons name="share-social" size={20} color="#ff6b93" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.courseTabs}>
        {['overview', 'materials', 'assignments', 'announcements'].map(tab => (
          <TouchableOpacity 
            key={tab}
            style={[styles.courseTab, activeTab === tab && styles.courseTabActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.courseTabText, activeTab === tab && styles.courseTabTextActive]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
            {activeTab === tab && <View style={styles.tabIndicator} />}
          </TouchableOpacity>
        ))}
      </View>
      
      <View style={styles.courseContent}>
        {activeTab === 'overview' && renderOverview()}
        {activeTab === 'materials' && renderMaterials()}
        {activeTab === 'assignments' && renderAssignments()}
        {activeTab === 'announcements' && renderAnnouncements()}
      </View>
      
      {renderMaterialModal()}
    </SafeAreaView>
  );
};

// ==============================================
// ✅ STUDENT DASHBOARD
// ==============================================
const StudentDashboard = ({ 
  onBack, 
  onCourseSelect, 
  courses, 
  materials, 
  notifications, 
  announcements, 
  assignments,
  onOpenMaterial,
  onSubmitAssignment,
 
  onMarkAllAsRead // Add this line
}) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [stats, setStats] = useState({
    totalCourses: 0,
    totalMaterials: 0,
    pendingAssignments: 0,
    unreadNotifications: 0
  });

  const studentId = "STUDENT_123";

  const updateStats = useCallback(() => {
    const pendingAssignments = assignments.filter(a => {
      const isSubmitted = a.submissions?.some(s => s.studentId === studentId);
      const isOverdue = a.dueDate && new Date(a.dueDate) < new Date();
      return !isSubmitted && !isOverdue;
    }).length;
    
    const unreadNotifications = notifications.filter(n => !n.read).length;
    
    setStats({
      totalCourses: courses.length,
      totalMaterials: materials.length,
      pendingAssignments,
      unreadNotifications
    });
  }, [courses, materials, assignments, notifications, studentId]);

  useEffect(() => {
    updateStats();
  }, [updateStats]);

  const onRefresh = async () => {
    setRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
    updateStats();
  };

  const filteredCourses = courses.filter(course => {
    if (!searchQuery.trim()) return true;
    
    const searchLower = searchQuery.toLowerCase();
    return (
      course.name?.toLowerCase().includes(searchLower) ||
      course.code?.toLowerCase().includes(searchLower) ||
      course.teacherName?.toLowerCase().includes(searchLower) ||
      course.description?.toLowerCase().includes(searchLower)
    );
  });

  const renderDashboard = () => (
    <ScrollView 
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl 
          refreshing={refreshing} 
          onRefresh={onRefresh}
          colors={['#ff6b93']}
          tintColor="#ff6b93"
        />
      }
    >
      <View style={styles.welcomeCard}>
        <View>
          <Text style={styles.welcomeText}>Welcome back, Student!</Text>
          <Text style={styles.welcomeSubtext}>Here's your learning progress</Text>
        </View>
        <View style={styles.avatarContainer}>
          <Text style={styles.avatarText}>👨‍🎓</Text>
        </View>
      </View>
      
      <View style={styles.statsGridDashboard}>
        <View style={[styles.statCardDashboard, styles.statCard1]}>
          <Ionicons name="book" size={24} color="#4dc3ff" />
          <Text style={styles.statNumberDashboard}>{stats.totalCourses}</Text>
          <Text style={styles.statLabelDashboard}>Courses</Text>
        </View>
        <View style={[styles.statCardDashboard, styles.statCard2]}>
          <Ionicons name="document" size={24} color="#33cc33" />
          <Text style={styles.statNumberDashboard}>{stats.totalMaterials}</Text>
          <Text style={styles.statLabelDashboard}>Materials</Text>
        </View>
        <View style={[styles.statCardDashboard, styles.statCard3]}>
          <Ionicons name="create" size={24} color="#ff9966" />
          <Text style={styles.statNumberDashboard}>{stats.pendingAssignments}</Text>
          <Text style={styles.statLabelDashboard}>Pending</Text>
        </View>
        <View style={[styles.statCardDashboard, styles.statCard4]}>
          <Ionicons name="notifications" size={24} color="#ff6b93" />
          <Text style={styles.statNumberDashboard}>{stats.unreadNotifications}</Text>
          <Text style={styles.statLabelDashboard}>Alerts</Text>
        </View>
      </View>
      
      <View style={styles.quickActions}>
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.actionButtonsRow}>
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={styles.quickActionIcon}>
              <Ionicons name="calendar" size={24} color="#4dc3ff" />
            </View>
            <Text style={styles.quickActionText}>Schedule</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickActionButton} onPress={() => setActiveTab('courses')}>
            <View style={styles.quickActionIcon}>
              <Ionicons name="document" size={24} color="#33cc33" />
            </View>
            <Text style={styles.quickActionText}>Materials</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={styles.quickActionIcon}>
              <Ionicons name="bar-chart" size={24} color="#ff9966" />
            </View>
            <Text style={styles.quickActionText}>Grades</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickActionButton}>
            <View style={styles.quickActionIcon}>
              <Ionicons name="chatbubbles" size={24} color="#ff6b93" />
            </View>
            <Text style={styles.quickActionText}>Messages</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.recentCourses}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Recent Courses</Text>
          <TouchableOpacity onPress={() => setActiveTab('courses')}>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        {courses.slice(0, 3).map(course => (
          <TouchableOpacity 
            key={course.id} 
            style={styles.recentCourseCard}
            onPress={() => onCourseSelect(course)}
          >
            <View style={styles.recentCourseIcon}>
              <Text style={styles.recentCourseIconText}>{course.code?.charAt(0) || 'C'}</Text>
            </View>
            <View style={styles.recentCourseInfo}>
              <Text style={styles.recentCourseTitle}>{course.code || 'CODE'}</Text>
              <Text style={styles.recentCourseName}>{course.name || 'Course Name'}</Text>
              <Text style={styles.recentCourseTeacher}>{course.teacherName || 'Teacher'}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#999" />
          </TouchableOpacity>
        ))}
      </View>
      
      <View style={styles.upcomingAssignments}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Upcoming Deadlines</Text>
          <TouchableOpacity>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>
        {assignments.slice(0, 2).map((assignment, index) => {
          const isSubmitted = assignment.submissions?.some(s => s.studentId === studentId);
          
          return (
            <View key={index} style={styles.assignmentReminderCard}>
              <View style={styles.assignmentReminderIcon}>
                <Ionicons 
                  name={isSubmitted ? "checkmark" : "flag"} 
                  size={20} 
                  color={isSubmitted ? "#33cc33" : "#ff9966"} 
                />
              </View>
              <View style={styles.assignmentReminderInfo}>
                <Text style={styles.assignmentReminderTitle}>{assignment.title || 'Assignment'}</Text>
                <Text style={styles.assignmentReminderCourse}>{assignment.courseCode || 'Course'}</Text>
                <Text style={styles.assignmentReminderDue}>Due: {assignment.dueDate || 'Soon'}</Text>
              </View>
              <TouchableOpacity style={styles.reminderActionButton}>
                <Text style={styles.reminderActionText}>{isSubmitted ? 'View' : 'Submit'}</Text>
              </TouchableOpacity>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );

  const renderCoursesList = () => (
    <FlatList
      data={filteredCourses}
      keyExtractor={item => item.id || Math.random().toString()}
      showsVerticalScrollIndicator={false}
      ListHeaderComponent={
        <>
          <View style={styles.searchContainer}>
            <View style={styles.searchInputContainer}>
              <Ionicons name="search" size={20} color="#999" />
              <TextInput
                style={styles.searchInput}
                placeholder="Search courses..."
                placeholderTextColor="#999"
                value={searchQuery}
                onChangeText={setSearchQuery}
              />
              {searchQuery.length > 0 && (
                <TouchableOpacity onPress={() => setSearchQuery('')}>
                  <Ionicons name="close-circle" size={20} color="#999" />
                </TouchableOpacity>
              )}
            </View>
            <TouchableOpacity style={styles.filterBtn}>
              <Ionicons name="filter" size={20} color="#ff6b93" />
            </TouchableOpacity>
          </View>
          
          <View style={styles.coursesHeader}>
            <Text style={styles.sectionTitle}>All Courses ({courses.length})</Text>
            <View style={styles.sortButtons}>
              <TouchableOpacity style={styles.sortBtn}>
                <Text style={styles.sortBtnText}>A-Z</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sortBtn}>
                <Text style={styles.sortBtnText}>Recent</Text>
              </TouchableOpacity>
            </View>
          </View>
        </>
      }
      renderItem={({ item: course }) => {
        const courseMaterials = materials.filter(m => m.courseCode === course.code).length;
        const courseAssignments = assignments.filter(a => a.courseCode === course.code).length;
        
        return (
          <TouchableOpacity 
            style={styles.courseListItem}
            onPress={() => onCourseSelect(course)}
          >
            <View style={styles.courseListItemIcon}>
              <Text style={styles.courseListItemIconText}>{course.code?.charAt(0) || 'C'}</Text>
            </View>
            <View style={styles.courseListItemInfo}>
              <Text style={styles.courseListItemCode}>{course.code || 'CODE'}</Text>
              <Text style={styles.courseListItemName}>{course.name || 'Course Name'}</Text>
              <View style={styles.courseListItemMeta}>
                <View style={styles.courseMetaItem}>
                  <Ionicons name="person" size={12} color="#666" />
                  <Text style={styles.courseMetaText}>{course.teacherName || 'Teacher'}</Text>
                </View>
                <View style={styles.courseMetaItem}>
                  <Ionicons name="time" size={12} color="#666" />
                  <Text style={styles.courseMetaText}>{course.schedule || 'Schedule'}</Text>
                </View>
              </View>
            </View>
            <View style={styles.courseListItemStats}>
              <View style={styles.courseStatItem}>
                <Ionicons name="document" size={14} color="#4dc3ff" />
                <Text style={styles.courseStatText}>{courseMaterials}</Text>
              </View>
              <View style={styles.courseStatItem}>
                <Ionicons name="create" size={14} color="#ff9966" />
                <Text style={styles.courseStatText}>{courseAssignments}</Text>
              </View>
            </View>
          </TouchableOpacity>
        );
      }}
      ListEmptyComponent={
        <View style={styles.emptyListContainer}>
          <Ionicons name="search" size={60} color="#ddd" />
          <Text style={styles.emptyListText}>No courses found</Text>
          <Text style={styles.emptyListSubtext}>Try a different search term</Text>
        </View>
      }
    />
  );

  return (
    <SafeAreaView style={styles.studentPortal}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <View style={styles.studentHeader}>
        <TouchableOpacity style={styles.backButton} onPress={onBack}>
          <Ionicons name="arrow-back" size={24} color="#ff6b93" />
        </TouchableOpacity>
        <View style={styles.studentInfo}>
          <Text style={styles.studentName}>Student Portal</Text>
          <Text style={styles.studentRole}>Learning Dashboard</Text>
        </View>
        <TouchableOpacity 
          style={styles.headerActionButton} 
          onPress={() => setShowNotifications(true)}
        >
          <Ionicons name="notifications" size={24} color="#ff6b93" />
          {stats.unreadNotifications > 0 && (
            <View style={styles.notificationBadge}>
              <Text style={styles.notificationBadgeText}>
                {stats.unreadNotifications > 9 ? '9+' : stats.unreadNotifications}
              </Text>
            </View>
          )}
        </TouchableOpacity>
      </View>
      
      <View style={styles.studentTabs}>
        <TouchableOpacity 
          style={[styles.studentTab, activeTab === 'dashboard' && styles.studentTabActive]}
          onPress={() => setActiveTab('dashboard')}
        >
          <Ionicons 
            name="grid" 
            size={20} 
            color={activeTab === 'dashboard' ? '#ff6b93' : '#666'} 
          />
          <Text style={[styles.studentTabText, activeTab === 'dashboard' && styles.studentTabTextActive]}>
            Dashboard
          </Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.studentTab, activeTab === 'courses' && styles.studentTabActive]}
          onPress={() => setActiveTab('courses')}
        >
          <Ionicons 
            name="book" 
            size={20} 
            color={activeTab === 'courses' ? '#ff6b93' : '#666'} 
          />
          <Text style={[styles.studentTabText, activeTab === 'courses' && styles.studentTabTextActive]}>
            Courses
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.studentContent}>
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'courses' && renderCoursesList()}
      </View>
      
     // In the StudentDashboard component, change this line:
<NotificationsModal
  visible={showNotifications}
  notifications={notifications}
  onClose={() => setShowNotifications(false)}
 onMarkAllAsRead={onMarkAllAsRead} 
/>
    </SafeAreaView>
  );
};

// ==============================================
// ✅ STUDENT PORTAL
// ==============================================
// ==============================================
// ==============================================
const StudentPortal = ({ onBack }) => {
  const [courses, setCourses] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  const studentId = "STUDENT_123";

  useEffect(() => {
    loadStudentData();
  }, []);

  const loadStudentData = async () => {
    setLoading(true);
    try {
      console.log('Loading student data...');
      
      // Fetch all data from Firestore
      const [coursesRes, materialsRes, notificationsRes, announcementsRes, assignmentsRes] = await Promise.all([
        fetchFromFirestore('courses'),
        fetchFromFirestore('materials'),
        fetchFromFirestore('notifications'),
        fetchFromFirestore('announcements'),
        fetchFromFirestore('assignments')
      ]);
      
      console.log('Student data loaded:', {
        courses: coursesRes.success ? coursesRes.data.length : 'failed',
        materials: materialsRes.success ? materialsRes.data.length : 'failed',
        notifications: notificationsRes.success ? notificationsRes.data.length : 'failed',
        announcements: announcementsRes.success ? announcementsRes.data.length : 'failed',
        assignments: assignmentsRes.success ? assignmentsRes.data.length : 'failed',
      });
      
      if (coursesRes.success) setCourses(coursesRes.data);
      if (materialsRes.success) setMaterials(materialsRes.data);
      if (notificationsRes.success) setNotifications(notificationsRes.data);
      if (announcementsRes.success) setAnnouncements(announcementsRes.data);
      if (assignmentsRes.success) setAssignments(assignmentsRes.data);
      
      // Handle fetch errors
      const errors = [];
      if (!coursesRes.success) errors.push(`Courses: ${coursesRes.error}`);
      if (!materialsRes.success) errors.push(`Materials: ${materialsRes.error}`);
      if (!notificationsRes.success) errors.push(`Notifications: ${notificationsRes.error}`);
      if (!announcementsRes.success) errors.push(`Announcements: ${announcementsRes.error}`);
      if (!assignmentsRes.success) errors.push(`Assignments: ${assignmentsRes.error}`);
      
      if (errors.length > 0) {
        console.warn('Some data failed to load:', errors);
      }
      
    } catch (error) {
      console.error('Error loading student data:', error);
      Alert.alert('Error', 'Failed to load data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenMaterial = async (materialId) => {
    try {
      const material = materials.find(m => m.id === materialId);
      if (material) {
        const updatedViews = (material.views || 0) + 1;
        const result = await saveToFirestore('materials', { views: updatedViews }, materialId);
        
        if (result.success) {
          setMaterials(materials.map(m => 
            m.id === materialId ? { ...m, views: updatedViews } : m
          ));
        }
      }
    } catch (error) {
      console.error('Error updating material views:', error);
    }
  };






  const handleSubmitAssignment = async (submissionData) => {
    try {
      const assignment = assignments.find(a => a.id === submissionData.assignmentId);
      if (!assignment) {
        return { success: false, error: 'Assignment not found' };
      }
      
      const updatedSubmissions = [
        ...(assignment.submissions || []),
        {
          studentId: submissionData.studentId,
          submission: submissionData.submission,
          submittedAt: submissionData.submittedAt,
          graded: false
        }
      ];
      
      const result = await saveToFirestore('assignments', 
        { submissions: updatedSubmissions }, 
        assignment.id
      );
      
      if (result.success) {
        setAssignments(assignments.map(a => 
          a.id === assignment.id ? { ...a, submissions: updatedSubmissions } : a
        ));
        
        // Create notification for teacher
        await saveToFirestore('notifications', {
          title: 'Assignment Submitted',
          message: `Student submitted assignment: ${assignment.title}`,
          courseCode: assignment.courseCode,
          type: 'assignment',
          priority: 'normal',
          read: false,
          timestamp: new Date().toISOString()
        });
      }
      
      return result;
    } catch (error) {
      console.error('Error submitting assignment:', error);
      return { success: false, error: error.message };
    }
  };

  // New function to delete all notifications
  const handleDeleteAllNotifications = async () => {
    try {
      if (notifications.length === 0) {
        Alert.alert('Info', 'No notifications to delete');
        return;
      }
      
      Alert.alert(
        'Clear All Notifications',
        'Are you sure you want to delete all notifications? This action cannot be undone.',
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Delete All', 
            style: 'destructive',
            onPress: async () => {
              setLoading(true);
              
              // Delete each notification individually
              const deletePromises = notifications.map(notification => 
                deleteFromFirestore('notifications', notification.id)
              );
              
              const results = await Promise.all(deletePromises);
              
              const failedDeletes = results.filter(result => !result.success);
              
              if (failedDeletes.length > 0) {
                console.warn('Some notifications failed to delete:', failedDeletes);
                Alert.alert('Partial Success', `Deleted ${notifications.length - failedDeletes.length} of ${notifications.length} notifications`);
              } else {
                Alert.alert('Success', 'All notifications deleted successfully');
              }
              
              // Clear local state
              setNotifications([]);
              setLoading(false);
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error deleting all notifications:', error);
      Alert.alert('Error', 'Failed to delete notifications');
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingScreen}>
        <ActivityIndicator size="large" color="#ff6b93" />
        <Text style={styles.loadingText}>Loading student portal...</Text>
      </SafeAreaView>
    );
  }

  if (selectedCourse) {
    return (
      <CourseDetailsPage
        course={selectedCourse}
        materials={materials}
        notifications={notifications}
        announcements={announcements}
        assignments={assignments}
        onBack={() => setSelectedCourse(null)}
        onOpenMaterial={handleOpenMaterial}
        onSubmitAssignment={handleSubmitAssignment}
        studentId={studentId}
      />
    );
  }

  return (
    <StudentDashboard
      onBack={onBack}
      onCourseSelect={setSelectedCourse}
      courses={courses}
      materials={materials}
      notifications={notifications}
      announcements={announcements}
      assignments={assignments}
      onOpenMaterial={handleOpenMaterial}
      onSubmitAssignment={handleSubmitAssignment}
      onMarkAllAsRead={handleDeleteAllNotifications} // Updated prop name
    />
  );
};

// ==============================================
// ✅ WELCOME SCREEN
// ==============================================
const WelcomeScreen = ({ onStudentAccess, onTeacherLogin }) => {
  const fadeAnim = new Animated.Value(0);
  const slideAnim = new Animated.Value(50);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  },);

  return (
    <SafeAreaView style={styles.welcomeContainer}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <View style={styles.welcomeBackground}>
        <View style={styles.welcomeOverlay}>
          <Animated.View 
            style={[
              styles.welcomeContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }]
              }
            ]}
          >
            <View style={styles.logoContainer}>
              <View style={styles.logoCircle}>
                <Ionicons name="school" size={60} color="#fff" />
              </View>
              <Text style={styles.welcomeTitle}> Education Portal </Text>
              <Text style={styles.welcomeSubtitle}>Learning Management System</Text>
            </View>
            
            <View style={styles.welcomeButtons}>
              <TouchableOpacity 
                style={[styles.welcomeButton, styles.studentButton]}
                onPress={onStudentAccess}
              >
                <View style={styles.buttonIconContainer}>
                  <Ionicons name="person-circle" size={28} color="#fff" />
                </View>
                <View style={styles.buttonTextContainer}>
                  <Text style={styles.welcomeButtonText}>Student Portal</Text>
                  <Text style={styles.welcomeButtonSubtext}>Access courses & materials</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="rgba(255,255,255,0.7)" />
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.welcomeButton, styles.teacherButton]}
                onPress={onTeacherLogin}
              >
                <View style={styles.buttonIconContainer}>
                  <Ionicons name="school" size={28} color="#fff" />
                </View>
                <View style={styles.buttonTextContainer}>
                  <Text style={styles.welcomeButtonText}>Teacher Portal</Text>
                  <Text style={styles.welcomeButtonSubtext}>Manage courses & students</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="rgba(255,255,255,0.7)" />
              </TouchableOpacity>
            </View>
            
            <View style={styles.welcomeFeatures}>
              <View style={styles.featureItem}>
                <Ionicons name="book" size={20} color="#4dc3ff" />
                <Text style={styles.featureText}>Course Management</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="document" size={20} color="#ff9966" />
                <Text style={styles.featureText}>Material Upload</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="analytics" size={20} color="#33cc33" />
                <Text style={styles.featureText}>Progress Tracking</Text>
              </View>
            </View>
          </Animated.View>
        </View>
      </View>
    </SafeAreaView>
  );
};

// ==============================================
// ✅ TEACHER LOGIN SCREEN
// ==============================================
const TeacherLoginScreen = ({ onBack, onLoginSuccess }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Authentication Required', 'Please enter both email and password');
      return;
    }

    if (!email.includes('@')) {
      Alert.alert('Invalid Email', 'Please enter a valid email address');
      return;
    }

    setLoading(true);
    const authResult = await authenticateTeacher(email, password);
    
    if (authResult.success) {
      Alert.alert('Welcome Back!', `Successfully logged in as ${authResult.user.name}`);
      onLoginSuccess(authResult.user);
    } else {
      Alert.alert('Login Failed', authResult.error || 'Invalid credentials.');
    }
    setLoading(false);
  };

  return (
    <SafeAreaView style={styles.loginContainerWrapper}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <ScrollView 
        contentContainerStyle={styles.loginScrollContainer}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.loginHeader}>
          <TouchableOpacity style={styles.backButtonTop} onPress={onBack}>
            <Ionicons name="arrow-back" size={24} color="#ff6b93" />
          </TouchableOpacity>
          
          <View style={styles.loginTitleContainer}>
            <View style={styles.loginIconCircle}>
              <Ionicons name="school" size={40} color="#fff" />
            </View>
            <Text style={styles.loginTitle}>Teacher Portal</Text>
            <Text style={styles.loginSubtitle}>Sign in to your account</Text>
          </View>
        </View>

        <View style={styles.loginForm}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Email Address</Text>
            <View style={styles.inputContainer}>
              <Ionicons name="mail" size={20} color="#ff6b93" style={styles.inputIcon} />
              <TextInput
                style={styles.loginInput}
                placeholder="Enter Email Address"
                placeholderTextColor="#aaa"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                editable={!loading}
              />
            </View>
          </View>
          
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Password</Text>
            <View style={styles.inputContainer}>
              <Ionicons name="lock-closed" size={20} color="#ff6b93" style={styles.inputIcon} />
              <TextInput
                style={styles.loginInput}
                placeholder="Enter your password"
                placeholderTextColor="#aaa"
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
                editable={!loading}
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                <Ionicons 
                  name={showPassword ? "eye-off" : "eye"} 
                  size={20} 
                  color="#ff6b93" 
                />
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.loginOptions}>
            <View style={styles.rememberMeContainer}>
              <Switch
                value={rememberMe}
                onValueChange={setRememberMe}
                trackColor={{ false: '#ddd', true: '#ff6b93' }}
                thumbColor={rememberMe ? '#fff' : '#f4f3f4'}
              />
              <Text style={styles.rememberMeText}>Remember me</Text>
            </View>
            
          </View>

          <TouchableOpacity 
            style={[styles.loginButton, loading && styles.loginButtonDisabled]} 
            onPress={handleLogin}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="white" />
            ) : (
              <>
                <Ionicons name="log-in" size={20} color="white" style={styles.loginButtonIcon} />
                <Text style={styles.loginButtonText}>SIGN IN</Text>
              </>
            )}
          </TouchableOpacity>

          <View style={styles.loginDivider}>
            <View style={styles.dividerLine} />
          
            <View style={styles.dividerLine} />
          </View>

          
        </View>

      
      </ScrollView>
    </SafeAreaView>
  );
};

// ==============================================
// ✅ TEACHER PORTAL
// ==============================================
// ✅ TEACHER PORTAL COMPONENT (Updated)
// ==============================================
const TeacherPortal = ({ onLogout, currentUser }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);
  
  // Data states
  const [courses, setCourses] = useState([]);
  const [materials, setMaterials] = useState([]);
  const [students, setStudents] = useState([]);
  const [results, setResults] = useState([]);
  const [attendance, setAttendance] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [assignments, setAssignments] = useState([]);
  
  // Form states
  const [newCourse, setNewCourse] = useState({
    code: '',
    name: '',
    description: '',
    schedule: '',
    credits: '3',
    duration: '16 Weeks',
    department: 'Computer Science',
    outcomes: ''
  });
  
  const [newMaterial, setNewMaterial] = useState({
    courseCode: '',
    title: '',
    type: 'lecture',
    description: '',
    fileUrl: '',
    fileSize: '',
    uploadedBy: ''
  });
  
  const [newStudent, setNewStudent] = useState({
    id: '',
    name: '',
    email: '',
    phone: '',
    semester: '1',
    department: 'Computer Science',
    courses: []
  });
  
  const [newResult, setNewResult] = useState({
    studentId: '',
    studentName: '',
    courseCode: '',
    assignmentTitle: '',
    marks: '',
    totalMarks: '100',
    grade: 'A',
    feedback: ''
  });
  
  const [newAttendance, setNewAttendance] = useState({
    studentId: '',
    studentName: '',
    courseCode: '',
    date: new Date().toISOString().split('T')[0],
    status: 'Present',
    remarks: ''
  });
  
  const [newNotification, setNewNotification] = useState({
    courseCode: '',
    title: '',
    message: '',
    type: 'general',
    priority: 'normal'
  });
  
  const [newAnnouncement, setNewAnnouncement] = useState({
    courseCode: '',
    title: '',
    message: '',
    attachments: []
  });
  
  const [newAssignment, setNewAssignment] = useState({
    courseCode: '',
    title: '',
    description: '',
    dueDate: new Date().toISOString().split('T')[0],
    totalPoints: '100',
    submissionType: 'file'
  });

  useEffect(() => {
    loadTeacherData();
  }, []);

  const loadTeacherData = async () => {
    try {
      setLoading(true);
      
      console.log('Loading teacher data...');
      
      const promises = [
        fetchFromFirestore('courses'),
        fetchFromFirestore('materials'),
        fetchFromFirestore('students'),
        fetchFromFirestore('results'),
        fetchFromFirestore('attendance'),
        fetchFromFirestore('notifications'),
        fetchFromFirestore('announcements'),
        fetchFromFirestore('assignments')
      ];
      
      const results = await Promise.all(promises);
      
      console.log('Teacher data loaded:', {
        courses: results[0].success ? results[0].data.length : 'failed',
        materials: results[1].success ? results[1].data.length : 'failed',
        students: results[2].success ? results[2].data.length : 'failed',
        results: results[3].success ? results[3].data.length : 'failed',
        attendance: results[4].success ? results[4].data.length : 'failed',
        notifications: results[5].success ? results[5].data.length : 'failed',
        announcements: results[6].success ? results[6].data.length : 'failed',
        assignments: results[7].success ? results[7].data.length : 'failed',
      });
      
      if (results[0].success) setCourses(results[0].data);
      if (results[1].success) setMaterials(results[1].data);
      if (results[2].success) setStudents(results[2].data);
      if (results[3].success) setResults(results[3].data);
      if (results[4].success) setAttendance(results[4].data);
      if (results[5].success) setNotifications(results[5].data);
      if (results[6].success) setAnnouncements(results[6].data);
      if (results[7].success) setAssignments(results[7].data);
      
      // Handle fetch errors
      const errors = [];
      results.forEach((result, index) => {
        if (!result.success) {
          const collectionNames = ['courses', 'materials', 'students', 'results', 'attendance', 'notifications', 'announcements', 'assignments'];
          errors.push(`${collectionNames[index]}: ${result.error}`);
        }
      });
      
      if (errors.length > 0) {
        console.warn('Some teacher data failed to load:', errors);
      }
      
    } catch (error) {
      console.error('Error loading teacher data:', error);
      Alert.alert('Error', 'Failed to load data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTeacherData();
    setRefreshing(false);
  };

  const handleSaveCourse = async () => {
    if (!newCourse.code || !newCourse.name || !newCourse.schedule) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Code, Name, Schedule)');
      return;
    }

    setLoading(true);
    const courseData = {
      ...newCourse,
      teacherId: currentUser.id,
      teacherName: currentUser.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      credits: parseInt(newCourse.credits) || 3,
      isActive: true
    };
    
    console.log('Saving course:', courseData);
    
    const result = await saveToFirestore('courses', courseData);
    
    if (result.success) {
      Alert.alert('Success', 'Course created successfully!');
      setNewCourse({
        code: '', name: '', description: '', schedule: '', credits: '3',
        duration: '16 Weeks', department: 'Computer Science', outcomes: ''
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to create course');
    }
    setLoading(false);
  };

  const handleSaveMaterial = async () => {
    if (!newMaterial.courseCode || !newMaterial.title || !newMaterial.description) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Course, Title, Description)');
      return;
    }

    setLoading(true);
    
    const materialData = {
      ...newMaterial,
      uploadedBy: currentUser.name,
      uploadDate: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      downloads: 0,
      views: 0
    };
    
    console.log('Saving material:', materialData);
    
    const result = await saveToFirestore('materials', materialData);
    
    if (result.success) {
      Alert.alert('Success', 'Material uploaded successfully!');
      setNewMaterial({ 
        courseCode: '', title: '', type: 'lecture', description: '',
        fileUrl: '', fileSize: '', uploadedBy: ''
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to upload material');
    }
    setLoading(false);
  };

  const handleSaveAssignment = async () => {
    if (!newAssignment.courseCode || !newAssignment.title || !newAssignment.dueDate) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Course, Title, Due Date)');
      return;
    }

    setLoading(true);
    const assignmentData = {
      ...newAssignment,
      createdBy: currentUser.name,
      createdAt: new Date().toISOString(),
      submissions: [],
      totalPoints: parseInt(newAssignment.totalPoints) || 100
    };
    
    console.log('Saving assignment:', assignmentData);
    
    const result = await saveToFirestore('assignments', assignmentData);
    
    if (result.success) {
      Alert.alert('Success', 'Assignment created successfully!');
      setNewAssignment({
        courseCode: '', title: '', description: '',
        dueDate: new Date().toISOString().split('T')[0],
        totalPoints: '100', submissionType: 'file'
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to create assignment');
    }
    setLoading(false);
  };

  const handleSaveAnnouncement = async () => {
    if (!newAnnouncement.courseCode || !newAnnouncement.title || !newAnnouncement.message) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Course, Title, Message)');
      return;
    }

    setLoading(true);
    const announcementData = {
      ...newAnnouncement,
      createdBy: currentUser.name,
      date: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
      readBy: []
    };
    
    console.log('Saving announcement:', announcementData);
    
    const result = await saveToFirestore('announcements', announcementData);
    
    if (result.success) {
      Alert.alert('Success', 'Announcement posted successfully!');
      setNewAnnouncement({ 
        courseCode: '', title: '', message: '', attachments: []
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to post announcement');
    }
    setLoading(false);
  };

  const handleSaveAttendance = async () => {
    if (!newAttendance.studentId || !newAttendance.courseCode || !newAttendance.date) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Student, Course, Date)');
      return;
    }

    setLoading(true);
    const attendanceData = {
      ...newAttendance,
      recordedBy: currentUser.name,
      recordedAt: new Date().toISOString(),
      timestamp: new Date().toISOString()
    };
    
    console.log('Saving attendance:', attendanceData);
    
    const result = await saveToFirestore('attendance', attendanceData);
    
    if (result.success) {
      Alert.alert('Success', 'Attendance recorded successfully!');
      setNewAttendance({
        studentId: '',
        studentName: '',
        courseCode: '',
        date: new Date().toISOString().split('T')[0],
        status: 'Present',
        remarks: ''
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to record attendance');
    }
    setLoading(false);
  };

  const handleSaveResult = async () => {
    if (!newResult.studentId || !newResult.courseCode || !newResult.marks) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Student, Course, Marks)');
      return;
    }

    setLoading(true);
    const resultData = {
      ...newResult,
      recordedBy: currentUser.name,
      recordedAt: new Date().toISOString(),
      marks: parseInt(newResult.marks) || 0,
      totalMarks: parseInt(newResult.totalMarks) || 100,
      grade: calculateGrade(parseInt(newResult.marks), parseInt(newResult.totalMarks))
    };
    
    console.log('Saving result:', resultData);
    
    const result = await saveToFirestore('results', resultData);
    
    if (result.success) {
      Alert.alert('Success', 'Result saved successfully!');
      setNewResult({
        studentId: '',
        studentName: '',
        courseCode: '',
        assignmentTitle: '',
        marks: '',
        totalMarks: '100',
        grade: 'A',
        feedback: ''
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to save result');
    }
    setLoading(false);
  };

  const handleSaveStudent = async () => {
    if (!newStudent.id || !newStudent.name || !newStudent.email) {
      Alert.alert('Validation Error', 'Please fill in all required fields (ID, Name, Email)');
      return;
    }

    setLoading(true);
    const studentData = {
      ...newStudent,
      enrolledAt: new Date().toISOString(),
      status: 'active'
    };
    
    console.log('Saving student:', studentData);
    
    const result = await saveToFirestore('students', studentData);
    
    if (result.success) {
      Alert.alert('Success', 'Student added successfully!');
      setNewStudent({
        id: '',
        name: '',
        email: '',
        phone: '',
        semester: '1',
        department: 'Computer Science',
        courses: []
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to add student');
    }
    setLoading(false);
  };

  const handleSaveNotification = async () => {
    if (!newNotification.title || !newNotification.message) {
      Alert.alert('Validation Error', 'Please fill in all required fields (Title, Message)');
      return;
    }

    setLoading(true);
    const notificationData = {
      ...newNotification,
      createdBy: currentUser.name,
      timestamp: new Date().toISOString(),
      read: false,
      readBy: []
    };
    
    console.log('Saving notification:', notificationData);
    
    const result = await saveToFirestore('notifications', notificationData);
    
    if (result.success) {
      Alert.alert('Success', 'Notification created successfully!');
      setNewNotification({
        courseCode: '',
        title: '',
        message: '',
        type: 'general',
        priority: 'normal'
      });
      setShowModal(false);
      await loadTeacherData();
    } else {
      Alert.alert('Error', result.error || 'Failed to create notification');
    }
    setLoading(false);
  };

  const handleDelete = async (collection, id, name) => {
    Alert.alert(
      'Confirm Delete',
      `Are you sure you want to delete "${name}"? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: async () => {
            setLoading(true);
            const result = await deleteFromFirestore(collection, id);
            if (result.success) {
              Alert.alert('Deleted', 'Item deleted successfully');
              await loadTeacherData();
            } else {
              Alert.alert('Error', result.error || 'Failed to delete item');
            }
            setLoading(false);
          }
        }
      ]
    );
  };

  // NEW: Function to delete all notifications
  const handleDeleteAllNotifications = async () => {
    try {
      if (notifications.length === 0) {
        Alert.alert('Info', 'No notifications to delete');
        return;
      }
      
      Alert.alert(
        'Clear All Notifications',
        `Are you sure you want to delete ${notifications.length} notifications? This action cannot be undone.`,
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'Delete All', 
            style: 'destructive',
            onPress: async () => {
              setLoading(true);
              
              // Delete each notification individually
              const deletePromises = notifications.map(notification => 
                deleteFromFirestore('notifications', notification.id)
              );
              
              const results = await Promise.all(deletePromises);
              
              const successCount = results.filter(r => r.success).length;
              const failedCount = results.filter(r => !r.success).length;
              
              if (failedCount > 0) {
                console.warn('Some notifications failed to delete');
                Alert.alert('Partial Success', `Deleted ${successCount} of ${notifications.length} notifications`);
              } else {
                Alert.alert('Success', `All ${notifications.length} notifications deleted successfully`);
              }
              
              // Clear local state
              setNotifications([]);
              setLoading(false);
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error deleting all notifications:', error);
      Alert.alert('Error', 'Failed to delete notifications');
      setLoading(false);
    }
  };

  // NEW: Function to delete all items from a collection (for admin purposes)
  const deleteAllFromCollection = async (collection, collectionName) => {
    try {
      const fetchResult = await fetchFromFirestore(collection);
      
      if (!fetchResult.success || !fetchResult.data.length) {
        Alert.alert('Info', `No ${collectionName} to delete`);
        return;
      }
      
      Alert.alert(
        `Delete All ${collectionName}`,
        `Are you sure you want to delete ALL ${fetchResult.data.length} ${collectionName}? This action is IRREVERSIBLE!`,
        [
          { text: 'Cancel', style: 'cancel' },
          { 
            text: 'DELETE ALL', 
            style: 'destructive',
            onPress: async () => {
              setLoading(true);
              
              // Delete each item individually
              const deletePromises = fetchResult.data.map(item => 
                deleteFromFirestore(collection, item.id)
              );
              
              const results = await Promise.all(deletePromises);
              
              const successCount = results.filter(r => r.success).length;
              
              Alert.alert('Complete', `Deleted ${successCount} ${collectionName}`);
              await loadTeacherData();
              setLoading(false);
            }
          }
        ]
      );
    } catch (error) {
      console.error(`Error deleting all ${collectionName}:`, error);
      Alert.alert('Error', `Failed to delete ${collectionName}`);
      setLoading(false);
    }
  };

  const filteredData = () => {
    let data = [];
    switch (activeTab) {
      case 'courses': data = courses; break;
      case 'materials': data = materials; break;
      case 'assignments': data = assignments; break;
      case 'students': data = students; break;
      case 'notifications': data = notifications; break;
      case 'announcements': data = announcements; break;
      case 'attendance': data = attendance; break;
      case 'results': data = results; break;
      default: data = [];
    }
    
    if (!searchText.trim()) return data;
    
    const searchLower = searchText.toLowerCase();
    return data.filter(item => {
      if (activeTab === 'courses') {
        return (item.name?.toLowerCase() || '').includes(searchLower) ||
               (item.code?.toLowerCase() || '').includes(searchLower) ||
               (item.description?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'materials') {
        return (item.title?.toLowerCase() || '').includes(searchLower) ||
               (item.description?.toLowerCase() || '').includes(searchLower) ||
               (item.courseCode?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'assignments') {
        return (item.title?.toLowerCase() || '').includes(searchLower) ||
               (item.courseCode?.toLowerCase() || '').includes(searchLower) ||
               (item.description?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'students') {
        return (item.name?.toLowerCase() || '').includes(searchLower) ||
               (item.email?.toLowerCase() || '').includes(searchLower) ||
               (item.id?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'notifications') {
        return (item.title?.toLowerCase() || '').includes(searchLower) ||
               (item.message?.toLowerCase() || '').includes(searchLower) ||
               (item.courseCode?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'announcements') {
        return (item.title?.toLowerCase() || '').includes(searchLower) ||
               (item.message?.toLowerCase() || '').includes(searchLower) ||
               (item.courseCode?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'attendance') {
        return (item.studentName?.toLowerCase() || '').includes(searchLower) ||
               (item.courseCode?.toLowerCase() || '').includes(searchLower) ||
               (item.status?.toLowerCase() || '').includes(searchLower);
      } else if (activeTab === 'results') {
        return (item.studentName?.toLowerCase() || '').includes(searchLower) ||
               (item.courseCode?.toLowerCase() || '').includes(searchLower) ||
               (item.assignmentTitle?.toLowerCase() || '').includes(searchLower);
      }
      return true;
    });
  };

  // NEW: NotificationsModal Component (Updated for deletion)
  const NotificationsModal = ({ visible, notifications, onClose, onDeleteAll }) => {
    const handleNotificationPress = (notification) => {
      Alert.alert(notification.title || 'Notification', notification.message || 'No message');
    };

    const handleDeleteAll = async () => {
      if (onDeleteAll) {
        await onDeleteAll();
      }
    };

    return (
      <Modal
        visible={visible}
        animationType="slide"
        transparent={true}
        onRequestClose={onClose}
      >
        <View style={styles.notificationsModalOverlay}>
          <View style={styles.notificationsModalContent}>
            <View style={styles.notificationsModalHeader}>
              <Text style={styles.notificationsModalTitle}>Notifications ({notifications.length})</Text>
              <TouchableOpacity onPress={onClose}>
                <Ionicons name="close" size={24} color="#ff6b93" />
              </TouchableOpacity>
            </View>
            
            <ScrollView style={styles.notificationsList}>
              {notifications.length === 0 ? (
                <View style={styles.emptyNotifications}>
                  <Ionicons name="notifications-off" size={60} color="#ddd" />
                  <Text style={styles.emptyNotificationsText}>No notifications</Text>
                  <Text style={styles.emptyNotificationsSubtext}>You're all caught up!</Text>
                </View>
              ) : (
                notifications.map((notification, index) => (
                  <TouchableOpacity 
                    key={notification.id || index} 
                    style={styles.notificationItem}
                    onPress={() => handleNotificationPress(notification)}
                  >
                    <View style={styles.notificationIcon}>
                      <Ionicons 
                        name="notifications" 
                        size={22} 
                        color="#ff6b93" 
                      />
                    </View>
                    <View style={styles.notificationContent}>
                      <Text style={styles.notificationTitle}>
                        {notification.title || 'Notification'}
                      </Text>
                      <Text style={styles.notificationMessage} numberOfLines={2}>
                        {notification.message || 'No message'}
                      </Text>
                      <View style={styles.notificationMeta}>
                        <Text style={styles.notificationType}>{notification.type || 'general'}</Text>
                        <Text style={styles.notificationTime}>
                          {notification.timestamp ? new Date(notification.timestamp).toLocaleDateString() : 'Recently'}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))
              )}
            </ScrollView>
            
            <View style={styles.notificationsModalFooter}>
              <TouchableOpacity 
                style={styles.deleteAllButton}
                onPress={handleDeleteAll}
                disabled={notifications.length === 0}
              >
                <Ionicons name="trash" size={18} color="#ff4757" />
                <Text style={styles.deleteAllText}>Clear All Notifications</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  const renderModal = () => {
    let modalContent = null;
    let handleSave = () => {};
    let title = '';

    switch (modalType) {
      case 'course':
        title = 'Create New Course';
        handleSave = handleSaveCourse;
        modalContent = (
          <>
            <View style={styles.modalRow}>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Course Code *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="CS101"
                  value={newCourse.code}
                  onChangeText={text => setNewCourse({...newCourse, code: text})}
                />
              </View>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Credits *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="3"
                  value={newCourse.credits}
                  onChangeText={text => setNewCourse({...newCourse, credits: text})}
                  keyboardType="numeric"
                />
              </View>
            </View>
            
            <Text style={styles.modalLabel}>Course Name *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Introduction to Programming"
              value={newCourse.name}
              onChangeText={text => setNewCourse({...newCourse, name: text})}
            />
            
            <Text style={styles.modalLabel}>Description</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Course description..."
              value={newCourse.description}
              onChangeText={text => setNewCourse({...newCourse, description: text})}
              multiline
              numberOfLines={3}
            />
            
            <View style={styles.modalRow}>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Schedule *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="Mon 10:00-11:30"
                  value={newCourse.schedule}
                  onChangeText={text => setNewCourse({...newCourse, schedule: text})}
                />
              </View>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Duration</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="16 Weeks"
                  value={newCourse.duration}
                  onChangeText={text => setNewCourse({...newCourse, duration: text})}
                />
              </View>
            </View>
            
            <Text style={styles.modalLabel}>Learning Outcomes (comma separated)</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Understand basic programming concepts, Write simple programs..."
              value={newCourse.outcomes}
              onChangeText={text => setNewCourse({...newCourse, outcomes: text})}
              multiline
              numberOfLines={2}
            />
          </>
        );
        break;

      case 'material':
        title = 'Upload Course Material';
        handleSave = handleSaveMaterial;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Select Course *</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              {courses.map(course => (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseOption,
                    newMaterial.courseCode === course.code && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewMaterial({...newMaterial, courseCode: course.code})}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newMaterial.courseCode === course.code && styles.courseOptionTextSelected
                  ]}>
                    {course.code}: {course.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Title *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Lecture 1: Introduction"
              value={newMaterial.title}
              onChangeText={text => setNewMaterial({...newMaterial, title: text})}
            />
            
            <Text style={styles.modalLabel}>Type *</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.typeScroll}>
              {['lecture', 'pdf', 'slides', 'assignment', 'code', 'video', 'quiz'].map(type => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.typeOption,
                    newMaterial.type === type && styles.typeOptionSelected
                  ]}
                  onPress={() => setNewMaterial({...newMaterial, type})}
                >
                  <Ionicons 
                    name={getMaterialIcon(type)} 
                    size={20} 
                    color={newMaterial.type === type ? '#fff' : getMaterialColor(type)} 
                  />
                  <Text style={[
                    styles.typeOptionText,
                    newMaterial.type === type && styles.typeOptionTextSelected
                  ]}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Description *</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Material description..."
              value={newMaterial.description}
              onChangeText={text => setNewMaterial({...newMaterial, description: text})}
              multiline
              numberOfLines={3}
            />
            
            <Text style={styles.modalLabel}>File URL (Optional)</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="https://example.com/file.pdf"
              value={newMaterial.fileUrl}
              onChangeText={text => setNewMaterial({...newMaterial, fileUrl: text})}
              keyboardType="url"
            />
            
            <Text style={styles.modalLabel}>File Size (Optional)</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="e.g., 2.5 MB"
              value={newMaterial.fileSize}
              onChangeText={text => setNewMaterial({...newMaterial, fileSize: text})}
            />
          </>
        );
        break;

      case 'assignment':
        title = 'Create Assignment';
        handleSave = handleSaveAssignment;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Select Course *</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              {courses.map(course => (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseOption,
                    newAssignment.courseCode === course.code && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewAssignment({...newAssignment, courseCode: course.code})}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newAssignment.courseCode === course.code && styles.courseOptionTextSelected
                  ]}>
                    {course.code}: {course.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Title *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Assignment 1: Programming Basics"
              value={newAssignment.title}
              onChangeText={text => setNewAssignment({...newAssignment, title: text})}
            />
            
            <Text style={styles.modalLabel}>Description</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Assignment instructions and requirements..."
              value={newAssignment.description}
              onChangeText={text => setNewAssignment({...newAssignment, description: text})}
              multiline
              numberOfLines={4}
            />
            
            <View style={styles.modalRow}>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Due Date *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="YYYY-MM-DD"
                  value={newAssignment.dueDate}
                  onChangeText={text => setNewAssignment({...newAssignment, dueDate: text})}
                />
              </View>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Total Points</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="100"
                  value={newAssignment.totalPoints}
                  onChangeText={text => setNewAssignment({...newAssignment, totalPoints: text})}
                  keyboardType="numeric"
                />
              </View>
            </View>
            
            <Text style={styles.modalLabel}>Submission Type</Text>
            <View style={styles.typeSelection}>
              {['file', 'text', 'link', 'mixed'].map(type => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.typeOption,
                    newAssignment.submissionType === type && styles.typeOptionSelected
                  ]}
                  onPress={() => setNewAssignment({...newAssignment, submissionType: type})}
                >
                  <Text style={[
                    styles.typeOptionText,
                    newAssignment.submissionType === type && styles.typeOptionTextSelected
                  ]}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        );
        break;

      case 'announcement':
        title = 'Post Announcement';
        handleSave = handleSaveAnnouncement;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Select Course</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              <TouchableOpacity
                style={[
                  styles.courseOption,
                  newAnnouncement.courseCode === 'all' && styles.courseOptionSelected
                ]}
                onPress={() => setNewAnnouncement({...newAnnouncement, courseCode: 'all'})}
              >
                <Text style={[
                  styles.courseOptionText,
                  newAnnouncement.courseCode === 'all' && styles.courseOptionTextSelected
                ]}>
                  All Courses
                </Text>
              </TouchableOpacity>
              {courses.map(course => (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseOption,
                    newAnnouncement.courseCode === course.code && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewAnnouncement({...newAnnouncement, courseCode: course.code})}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newAnnouncement.courseCode === course.code && styles.courseOptionTextSelected
                  ]}>
                    {course.code}: {course.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Title *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Important Announcement"
              value={newAnnouncement.title}
              onChangeText={text => setNewAnnouncement({...newAnnouncement, title: text})}
            />
            
            <Text style={styles.modalLabel}>Message *</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Type your announcement here..."
              value={newAnnouncement.message}
              onChangeText={text => setNewAnnouncement({...newAnnouncement, message: text})}
              multiline
              numberOfLines={6}
            />
            
            <Text style={styles.modalLabel}>Attachments (Optional)</Text>
            <TouchableOpacity style={styles.addAttachmentButton}>
              <Ionicons name="attach" size={20} color="#4dc3ff" />
              <Text style={styles.addAttachmentText}>Add Attachment</Text>
            </TouchableOpacity>
          </>
        );
        break;

      case 'attendance':
        title = 'Record Attendance';
        handleSave = handleSaveAttendance;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Select Student</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              {students.map(student => (
                <TouchableOpacity
                  key={student.id}
                  style={[
                    styles.courseOption,
                    newAttendance.studentId === student.id && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewAttendance({
                    ...newAttendance, 
                    studentId: student.id,
                    studentName: student.name
                  })}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newAttendance.studentId === student.id && styles.courseOptionTextSelected
                  ]}>
                    {student.id}: {student.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Select Course *</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              {courses.map(course => (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseOption,
                    newAttendance.courseCode === course.code && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewAttendance({...newAttendance, courseCode: course.code})}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newAttendance.courseCode === course.code && styles.courseOptionTextSelected
                  ]}>
                    {course.code}: {course.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Date *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="YYYY-MM-DD"
              value={newAttendance.date}
              onChangeText={text => setNewAttendance({...newAttendance, date: text})}
            />
            
            <Text style={styles.modalLabel}>Status *</Text>
            <View style={styles.typeSelection}>
              {['Present', 'Absent', 'Late', 'Excused'].map(status => (
                <TouchableOpacity
                  key={status}
                  style={[
                    styles.typeOption,
                    newAttendance.status === status && styles.typeOptionSelected
                  ]}
                  onPress={() => setNewAttendance({...newAttendance, status})}
                >
                  <Text style={[
                    styles.typeOptionText,
                    newAttendance.status === status && styles.typeOptionTextSelected
                  ]}>
                    {status}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            
            <Text style={styles.modalLabel}>Remarks (Optional)</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Additional remarks..."
              value={newAttendance.remarks}
              onChangeText={text => setNewAttendance({...newAttendance, remarks: text})}
              multiline
              numberOfLines={2}
            />
          </>
        );
        break;

      case 'result':
        title = 'Record Result';
        handleSave = handleSaveResult;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Select Student</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              {students.map(student => (
                <TouchableOpacity
                  key={student.id}
                  style={[
                    styles.courseOption,
                    newResult.studentId === student.id && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewResult({
                    ...newResult, 
                    studentId: student.id,
                    studentName: student.name
                  })}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newResult.studentId === student.id && styles.courseOptionTextSelected
                  ]}>
                    {student.id}: {student.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Select Course *</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              {courses.map(course => (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseOption,
                    newResult.courseCode === course.code && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewResult({...newResult, courseCode: course.code})}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newResult.courseCode === course.code && styles.courseOptionTextSelected
                  ]}>
                    {course.code}: {course.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Assignment Title</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Assignment 1, Quiz 2, etc."
              value={newResult.assignmentTitle}
              onChangeText={text => setNewResult({...newResult, assignmentTitle: text})}
            />
            
            <View style={styles.modalRow}>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Marks Obtained *</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="85"
                  value={newResult.marks}
                  onChangeText={text => setNewResult({...newResult, marks: text})}
                  keyboardType="numeric"
                />
              </View>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Total Marks</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="100"
                  value={newResult.totalMarks}
                  onChangeText={text => setNewResult({...newResult, totalMarks: text})}
                  keyboardType="numeric"
                />
              </View>
            </View>
            
            <Text style={styles.modalLabel}>Grade</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="A, B, C, etc."
              value={newResult.grade}
              onChangeText={text => setNewResult({...newResult, grade: text})}
            />
            
            <Text style={styles.modalLabel}>Feedback (Optional)</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Provide feedback to the student..."
              value={newResult.feedback}
              onChangeText={text => setNewResult({...newResult, feedback: text})}
              multiline
              numberOfLines={3}
            />
          </>
        );
        break;

      case 'student':
        title = 'Add Student';
        handleSave = handleSaveStudent;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Student ID *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="STUDENT001"
              value={newStudent.id}
              onChangeText={text => setNewStudent({...newStudent, id: text})}
            />
            
            <Text style={styles.modalLabel}>Full Name *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="John Doe"
              value={newStudent.name}
              onChangeText={text => setNewStudent({...newStudent, name: text})}
            />
            
            <Text style={styles.modalLabel}>Email *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="john.doe@example.com"
              value={newStudent.email}
              onChangeText={text => setNewStudent({...newStudent, email: text})}
              keyboardType="email-address"
            />
            
            <View style={styles.modalRow}>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Phone</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="+1234567890"
                  value={newStudent.phone}
                  onChangeText={text => setNewStudent({...newStudent, phone: text})}
                  keyboardType="phone-pad"
                />
              </View>
              <View style={styles.modalColumn}>
                <Text style={styles.modalLabel}>Semester</Text>
                <TextInput
                  style={styles.modalInput}
                  placeholder="1"
                  value={newStudent.semester}
                  onChangeText={text => setNewStudent({...newStudent, semester: text})}
                  keyboardType="numeric"
                />
              </View>
            </View>
            
            <Text style={styles.modalLabel}>Department</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Computer Science"
              value={newStudent.department}
              onChangeText={text => setNewStudent({...newStudent, department: text})}
            />
          </>
        );
        break;

      case 'notification':
        title = 'Create Notification';
        handleSave = handleSaveNotification;
        modalContent = (
          <>
            <Text style={styles.modalLabel}>Select Course</Text>
            <ScrollView style={styles.courseListContainer} nestedScrollEnabled>
              <TouchableOpacity
                style={[
                  styles.courseOption,
                  newNotification.courseCode === 'all' && styles.courseOptionSelected
                ]}
                onPress={() => setNewNotification({...newNotification, courseCode: 'all'})}
              >
                <Text style={[
                  styles.courseOptionText,
                  newNotification.courseCode === 'all' && styles.courseOptionTextSelected
                ]}>
                  All Courses
                </Text>
              </TouchableOpacity>
              {courses.map(course => (
                <TouchableOpacity
                  key={course.id}
                  style={[
                    styles.courseOption,
                    newNotification.courseCode === course.code && styles.courseOptionSelected
                  ]}
                  onPress={() => setNewNotification({...newNotification, courseCode: course.code})}
                >
                  <Text style={[
                    styles.courseOptionText,
                    newNotification.courseCode === course.code && styles.courseOptionTextSelected
                  ]}>
                    {course.code}: {course.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            
            <Text style={styles.modalLabel}>Title *</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Notification Title"
              value={newNotification.title}
              onChangeText={text => setNewNotification({...newNotification, title: text})}
            />
            
            <Text style={styles.modalLabel}>Message *</Text>
            <TextInput
              style={[styles.modalInput, styles.textArea]}
              placeholder="Notification message..."
              value={newNotification.message}
              onChangeText={text => setNewNotification({...newNotification, message: text})}
              multiline
              numberOfLines={4}
            />
            
            <Text style={styles.modalLabel}>Type</Text>
            <View style={styles.typeSelection}>
              {['general', 'assignment', 'announcement', 'reminder', 'urgent'].map(type => (
                <TouchableOpacity
                  key={type}
                  style={[
                    styles.typeOption,
                    newNotification.type === type && styles.typeOptionSelected
                  ]}
                  onPress={() => setNewNotification({...newNotification, type})}
                >
                  <Text style={[
                    styles.typeOptionText,
                    newNotification.type === type && styles.typeOptionTextSelected
                  ]}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            
            <Text style={styles.modalLabel}>Priority</Text>
            <View style={styles.typeSelection}>
              {['low', 'normal', 'high', 'urgent'].map(priority => (
                <TouchableOpacity
                  key={priority}
                  style={[
                    styles.typeOption,
                    newNotification.priority === priority && styles.typeOptionSelected
                  ]}
                  onPress={() => setNewNotification({...newNotification, priority})}
                >
                  <Text style={[
                    styles.typeOptionText,
                    newNotification.priority === priority && styles.typeOptionTextSelected
                  ]}>
                    {priority.charAt(0).toUpperCase() + priority.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </>
        );
        break;
    }

    return (
      <Modal
        visible={showModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => {
          setShowModal(false);
        }}
      >
        <View style={styles.fullModalOverlay}>
          <View style={styles.fullModalContent}>
            <View style={styles.fullModalHeader}>
              <Text style={styles.fullModalTitle}>{title}</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <Ionicons name="close" size={24} color="#ff6b93" />
              </TouchableOpacity>
            </View>
            
            <ScrollView 
              style={styles.fullModalBody}
              contentContainerStyle={styles.fullModalBodyContent}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              {modalContent}
            </ScrollView>
            
            <View style={styles.fullModalFooter}>
              <TouchableOpacity 
                style={styles.cancelButtonLarge}
                onPress={() => setShowModal(false)}
              >
                <Text style={styles.cancelButtonTextLarge}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.confirmButtonLarge}
                onPress={handleSave}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="white" size="small" />
                ) : (
                  <>
                    <Ionicons name="checkmark" size={20} color="white" />
                    <Text style={styles.confirmButtonTextLarge}>Save</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };

 

  const renderDashboard = () => {
    const totalStudents = students.length;
    const totalMaterials = materials.length;
    const pendingSubmissions = assignments.reduce((acc, a) => {
      const courseStudents = students.filter(s => s.courses?.includes(a.courseCode)).length;
      const submittedCount = a.submissions?.length || 0;
      return acc + Math.max(0, courseStudents - submittedCount);
    }, 0);
    
    return (
      <ScrollView 
        style={styles.teacherContent}
        refreshControl={
          <RefreshControl 
            refreshing={refreshing} 
            onRefresh={onRefresh}
            colors={['#ff6b93']}
            tintColor="#ff6b93"
          />
        }
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.teacherWelcomeCard}>
          <View>
            <Text style={styles.teacherWelcomeText}>Welcome back, {currentUser?.name}!</Text>
            <Text style={styles.teacherWelcomeSubtext}>Here's your teaching overview</Text>
          </View>
          <TouchableOpacity style={styles.profileButton}>
            <Text style={styles.profileText}>{currentUser?.avatar || '👨‍🏫'}</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.statsGridTeacher}>
          <View style={[styles.statCardTeacher, styles.statCard1]}>
            <Ionicons name="book" size={28} color="#4dc3ff" />
            <Text style={styles.statNumberTeacher}>{courses.length}</Text>
            <Text style={styles.statLabelTeacher}>Courses</Text>
          </View>
          <View style={[styles.statCardTeacher, styles.statCard2]}>
            <Ionicons name="people" size={28} color="#33cc33" />
            <Text style={styles.statNumberTeacher}>{totalStudents}</Text>
            <Text style={styles.statLabelTeacher}>Students</Text>
          </View>
          <View style={[styles.statCardTeacher, styles.statCard3]}>
            <Ionicons name="document" size={28} color="#ff9966" />
            <Text style={styles.statNumberTeacher}>{totalMaterials}</Text>
            <Text style={styles.statLabelTeacher}>Materials</Text>
          </View>
          <View style={[styles.statCardTeacher, styles.statCard4]}>
            <Ionicons name="time" size={28} color="#ff6b93" />
            <Text style={styles.statNumberTeacher}>{pendingSubmissions}</Text>
            <Text style={styles.statLabelTeacher}>Pending</Text>
          </View>
        </View>
        
        <View style={styles.quickActionsDashboard}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionGridDashboard}>
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => { setModalType('course'); setShowModal(true); }}
            >
              <View style={[styles.actionIcon, styles.actionIcon1]}>
                <Ionicons name="add-circle" size={24} color="#fff" />
              </View>
              <Text style={styles.actionTitle}>New Course</Text>
              <Text style={styles.actionDescription}>Create course</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => { setModalType('material'); setShowModal(true); }}
            >
              <View style={[styles.actionIcon, styles.actionIcon2]}>
                <Ionicons name="document" size={24} color="#fff" />
              </View>
              <Text style={styles.actionTitle}>Upload Material</Text>
              <Text style={styles.actionDescription}>Add files/links</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => { setModalType('assignment'); setShowModal(true); }}
            >
              <View style={[styles.actionIcon, styles.actionIcon3]}>
                <Ionicons name="create" size={24} color="#fff" />
              </View>
              <Text style={styles.actionTitle}>Create Assignment</Text>
              <Text style={styles.actionDescription}>Set tasks</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.actionCard}
              onPress={() => { setModalType('announcement'); setShowModal(true); }}
            >
              <View style={[styles.actionIcon, styles.actionIcon4]}>
                <Ionicons name="megaphone" size={24} color="#fff" />
              </View>
              <Text style={styles.actionTitle}>Post Announcement</Text>
              <Text style={styles.actionDescription}>Share updates</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.recentActivity}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Activity</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.activityList}>
            {materials.slice(0, 3).map((material, index) => (
              <View key={index} style={styles.activityItem}>
                <View style={[styles.activityIcon, { backgroundColor: '#e6f7ff' }]}>
                  <Ionicons name="document" size={16} color="#4dc3ff" />
                </View>
                <View style={styles.activityInfo}>
                  <Text style={styles.activityTitle}>New material uploaded</Text>
                  <Text style={styles.activityDescription}>{material.title}</Text>
                  <Text style={styles.activityTime}>{material.uploadDate}</Text>
                </View>
              </View>
            ))}
            
            {assignments.slice(0, 2).map((assignment, index) => (
              <View key={index} style={styles.activityItem}>
                <View style={[styles.activityIcon, { backgroundColor: '#fff9f0' }]}>
                  <Ionicons name="create" size={16} color="#ff9966" />
                </View>
                <View style={styles.activityInfo}>
                  <Text style={styles.activityTitle}>New assignment created</Text>
                  <Text style={styles.activityDescription}>{assignment.title}</Text>
                  <Text style={styles.activityTime}>{assignment.dueDate}</Text>
                </View>
              </View>
            ))}
          </View>
        </View>
        
        <View style={styles.upcomingDeadlines}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Upcoming Deadlines</Text>
            <TouchableOpacity onPress={() => setActiveTab('assignments')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          {assignments.slice(0, 2).map((assignment, index) => {
            const courseStudents = students.filter(s => s.courses?.includes(assignment.courseCode)).length;
            const submissionCount = assignment.submissions?.length || 0;
            
            return (
              <View key={index} style={styles.deadlineCard}>
                <View style={styles.deadlineIcon}>
                  <Ionicons name="flag" size={20} color="#ff9966" />
                </View>
                <View style={styles.deadlineInfo}>
                  <Text style={styles.deadlineTitle}>{assignment.title}</Text>
                  <Text style={styles.deadlineCourse}>{assignment.courseCode}</Text>
                  <Text style={styles.deadlineDue}>Due: {assignment.dueDate}</Text>
                </View>
                <View style={styles.deadlineStats}>
                  <Text style={styles.deadlineStatText}>
                    {submissionCount}/{courseStudents} submitted
                  </Text>
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    );
  };

  const renderCourses = () => (
    <View style={styles.teacherContent}>
      {showSearch && (
        <View style={styles.searchContainerTeacher}>
          <View style={styles.searchInputContainer}>
            <Ionicons name="search" size={20} color="#999" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search courses..."
              placeholderTextColor="#999"
              value={searchText}
              onChangeText={setSearchText}
              autoFocus
            />
            <TouchableOpacity onPress={() => {
              setSearchText('');
              setShowSearch(false);
            }}>
              <Ionicons name="close" size={20} color="#999" />
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      <View style={styles.sectionHeaderWithActionsTeacher}>
        <Text style={styles.sectionTitle}>My Courses ({filteredData().length})</Text>
        <View style={styles.headerActionsRight}>
          <TouchableOpacity 
            style={styles.headerActionButton}
            onPress={() => setShowSearch(!showSearch)}
          >
            <Ionicons name="search" size={20} color="#666" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.addButtonLarge}
            onPress={() => { setModalType('course'); setShowModal(true); }}
          >
            <Ionicons name="add" size={20} color="white" />
            <Text style={styles.addButtonText}>New Course</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {filteredData().length === 0 ? (
        <View style={styles.emptyStateCardTeacher}>
          <Ionicons name="book" size={60} color="#ddd" />
          <Text style={styles.emptyStateText}>No courses created yet</Text>
          <Text style={styles.emptyStateSubtext}>Create your first course to get started</Text>
          <TouchableOpacity 
            style={styles.emptyStateButton}
            onPress={() => { setModalType('course'); setShowModal(true); }}
          >
            <Text style={styles.emptyStateButtonText}>Create Course</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredData()}
          keyExtractor={item => item.id || Math.random().toString()}
          showsVerticalScrollIndicator={false}
          renderItem={({ item: course }) => {
            const courseMaterials = materials.filter(m => m.courseCode === course.code).length;
            const courseStudents = students.filter(s => s.courses?.includes(course.code)).length;
            const courseAssignments = assignments.filter(a => a.courseCode === course.code).length;
            
            return (
              <View style={styles.courseManagementCard}>
                <View style={styles.courseManagementHeader}>
                  <View style={styles.courseCodeCircleLarge}>
                    <Text style={styles.courseCodeCharLarge}>{course.code?.charAt(0) || 'C'}</Text>
                  </View>
                  <View style={styles.courseManagementInfo}>
                    <Text style={styles.courseManagementCode}>{course.code || 'CODE'}</Text>
                    <Text style={styles.courseManagementName}>{course.name || 'Course Name'}</Text>
                    <Text style={styles.courseManagementTeacher}>{course.teacherName || 'Teacher'}</Text>
                  </View>
                  <View style={styles.courseActions}>
                    <TouchableOpacity style={styles.actionButtonSmall}>
                      <Ionicons name="create" size={16} color="#4dc3ff" />
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.actionButtonSmall}
                      onPress={() => handleDelete('courses', course.id, course.name)}
                    >
                      <Ionicons name="trash" size={16} color="#ff6666" />
                    </TouchableOpacity>
                  </View>
                </View>
                
                <Text style={styles.courseManagementDescription}>{course.description || 'No description'}</Text>
                
                <View style={styles.courseManagementStats}>
                  <View style={styles.courseStatCard}>
                    <Ionicons name="people" size={16} color="#33cc33" />
                    <Text style={styles.courseStatValue}>{courseStudents}</Text>
                    <Text style={styles.courseStatLabel}>Students</Text>
                  </View>
                  <View style={styles.courseStatCard}>
                    <Ionicons name="document" size={16} color="#4dc3ff" />
                    <Text style={styles.courseStatValue}>{courseMaterials}</Text>
                    <Text style={styles.courseStatLabel}>Materials</Text>
                  </View>
                  <View style={styles.courseStatCard}>
                    <Ionicons name="create" size={16} color="#ff9966" />
                    <Text style={styles.courseStatValue}>{courseAssignments}</Text>
                    <Text style={styles.courseStatLabel}>Assignments</Text>
                  </View>
                </View>
                
                <View style={styles.courseManagementActions}>
                  <TouchableOpacity style={styles.courseActionButton}>
                    <Ionicons name="eye" size={16} color="#666" />
                    <Text style={styles.courseActionText}>View</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.courseActionButton}>
                    <Ionicons name="settings" size={16} color="#666" />
                    <Text style={styles.courseActionText}>Manage</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.courseActionButton}>
                    <Ionicons name="analytics" size={16} color="#666" />
                    <Text style={styles.courseActionText}>Analytics</Text>
                  </TouchableOpacity>
                </View>
              </View>
            );
          }}
        />
      )}
    </View>
  );

  const renderMaterialsTab = () => (
    <View style={styles.teacherContent}>
      {showSearch && (
        <View style={styles.searchContainerTeacher}>
          <View style={styles.searchInputContainer}>
            <Ionicons name="search" size={20} color="#999" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search materials..."
              placeholderTextColor="#999"
              value={searchText}
              onChangeText={setSearchText}
              autoFocus
            />
            <TouchableOpacity onPress={() => {
              setSearchText('');
              setShowSearch(false);
            }}>
              <Ionicons name="close" size={20} color="#999" />
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      <View style={styles.sectionHeaderWithActionsTeacher}>
        <Text style={styles.sectionTitle}>Course Materials ({filteredData().length})</Text>
        <View style={styles.headerActionsRight}>
          <TouchableOpacity 
            style={styles.headerActionButton}
            onPress={() => setShowSearch(!showSearch)}
          >
            <Ionicons name="search" size={20} color="#666" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.addButtonLarge}
            onPress={() => { setModalType('material'); setShowModal(true); }}
          >
            <Ionicons name="add" size={20} color="white" />
            <Text style={styles.addButtonText}>Upload</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {filteredData().length === 0 ? (
        <View style={styles.emptyStateCardTeacher}>
          <Ionicons name="document" size={60} color="#ddd" />
          <Text style={styles.emptyStateText}>No materials uploaded</Text>
          <Text style={styles.emptyStateSubtext}>Upload your first material</Text>
          <TouchableOpacity 
            style={styles.emptyStateButton}
            onPress={() => { setModalType('material'); setShowModal(true); }}
          >
            <Text style={styles.emptyStateButtonText}>Upload Material</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredData()}
          keyExtractor={item => item.id || Math.random().toString()}
          showsVerticalScrollIndicator={false}
          renderItem={({ item: material }) => (
            <View style={styles.materialManagementCard}>
              <View style={styles.materialHeader}>
                <View style={[
                  styles.materialTypeBadge,
                  { backgroundColor: getMaterialColor(material.type) + '20' }
                ]}>
                  <Ionicons 
                    name={getMaterialIcon(material.type)} 
                    size={18} 
                    color={getMaterialColor(material.type)} 
                  />
                  <Text style={[
                    styles.materialTypeText,
                    { color: getMaterialColor(material.type) }
                  ]}>
                    {material.type}
                  </Text>
                </View>
                <View style={styles.materialActions}>
                  <TouchableOpacity style={styles.materialActionButton}>
                    <Ionicons name="share" size={16} color="#666" />
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.materialActionButton}
                    onPress={() => handleDelete('materials', material.id, material.title)}
                  >
                    <Ionicons name="trash" size={16} color="#ff6666" />
                  </TouchableOpacity>
                </View>
              </View>
              
              <Text style={styles.materialManagementTitle}>{material.title}</Text>
              <Text style={styles.materialManagementDescription}>{material.description}</Text>
              
              <View style={styles.materialDetails}>
                <View style={styles.materialDetailItem}>
                  <Ionicons name="book" size={14} color="#666" />
                  <Text style={styles.materialDetailText}>{material.courseCode}</Text>
                </View>
                <View style={styles.materialDetailItem}>
                  <Ionicons name="calendar" size={14} color="#666" />
                  <Text style={styles.materialDetailText}>{material.uploadDate}</Text>
                </View>
                <View style={styles.materialDetailItem}>
                  <Ionicons name="person" size={14} color="#666" />
                  <Text style={styles.materialDetailText}>{material.uploadedBy}</Text>
                </View>
              </View>
              
              {material.fileUrl && (
                <TouchableOpacity 
                  style={styles.materialLinkButton}
                  onPress={() => Linking.openURL(material.fileUrl).catch(() => Alert.alert('Error', 'Cannot open URL'))}
                >
                  <Ionicons name="link" size={16} color="#4dc3ff" />
                  <Text style={styles.materialLinkText}>View File</Text>
                </TouchableOpacity>
              )}
              
              <View style={styles.materialStats}>
                <View style={styles.materialStat}>
                  <Ionicons name="eye" size={14} color="#999" />
                  <Text style={styles.materialStatText}>{material.views || 0} views</Text>
                </View>
                <View style={styles.materialStat}>
                  <Ionicons name="download" size={14} color="#999" />
                  <Text style={styles.materialStatText}>{material.downloads || 0} downloads</Text>
                </View>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );

  const renderAssignmentsTab = () => {
    const currentAssignments = filteredData();
    
    return (
      <View style={styles.teacherContent}>
        {showSearch && (
          <View style={styles.searchContainerTeacher}>
            <View style={styles.searchInputContainer}>
              <Ionicons name="search" size={20} color="#999" />
              <TextInput
                style={styles.searchInput}
                placeholder="Search assignments..."
                placeholderTextColor="#999"
                value={searchText}
                onChangeText={setSearchText}
                autoFocus
              />
              <TouchableOpacity onPress={() => {
                setSearchText('');
                setShowSearch(false);
              }}>
                <Ionicons name="close" size={20} color="#999" />
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        <View style={styles.sectionHeaderWithActionsTeacher}>
          <Text style={styles.sectionTitle}>Assignments ({currentAssignments.length})</Text>
          <View style={styles.headerActionsRight}>
            <TouchableOpacity 
              style={styles.headerActionButton}
              onPress={() => setShowSearch(!showSearch)}
            >
              <Ionicons name="search" size={20} color="#666" />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.addButtonLarge}
              onPress={() => { setModalType('assignment'); setShowModal(true); }}
            >
              <Ionicons name="add" size={20} color="white" />
              <Text style={styles.addButtonText}>New Assignment</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {currentAssignments.length === 0 ? (
          <View style={styles.emptyStateCardTeacher}>
            <Ionicons name="create" size={60} color="#ddd" />
            <Text style={styles.emptyStateText}>No assignments created</Text>
            <Text style={styles.emptyStateSubtext}>Create your first assignment</Text>
            <TouchableOpacity 
              style={styles.emptyStateButton}
              onPress={() => { setModalType('assignment'); setShowModal(true); }}
            >
              <Text style={styles.emptyStateButtonText}>Create Assignment</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={currentAssignments}
            keyExtractor={item => item.id || Math.random().toString()}
            showsVerticalScrollIndicator={false}
            renderItem={({ item: assignment }) => {
              const submissionCount = assignment.submissions?.length || 0;
              const gradedCount = assignment.submissions?.filter(s => s.graded).length || 0;
              const courseStudents = students.filter(s => s.courses?.includes(assignment.courseCode)).length;
              
              return (
                <View style={styles.assignmentManagementCard}>
                  <View style={styles.assignmentManagementHeader}>
                    <View>
                      <Text style={styles.assignmentManagementTitle}>{assignment.title || 'Untitled Assignment'}</Text>
                      <Text style={styles.assignmentCourse}>{assignment.courseCode || 'No Course'}</Text>
                    </View>
                    <View style={styles.assignmentActions}>
                      <TouchableOpacity style={styles.assignmentActionButton}>
                        <Ionicons name="create" size={16} color="#4dc3ff" />
                      </TouchableOpacity>
                      <TouchableOpacity 
                        style={styles.assignmentActionButton}
                        onPress={() => handleDelete('assignments', assignment.id, assignment.title)}
                      >
                        <Ionicons name="trash" size={16} color="#ff6666" />
                      </TouchableOpacity>
                    </View>
                  </View>
                  
                  <Text style={styles.assignmentManagementDescription}>{assignment.description || 'No description provided'}</Text>
                  
                  <View style={styles.assignmentDetails}>
                    <View style={styles.assignmentDetailItem}>
                      <Ionicons name="calendar" size={14} color="#666" />
                      <Text style={styles.assignmentDetailText}>Due: {assignment.dueDate || 'No due date'}</Text>
                    </View>
                    <View style={styles.assignmentDetailItem}>
                      <Ionicons name="trophy" size={14} color="#666" />
                      <Text style={styles.assignmentDetailText}>{assignment.totalPoints || 100} points</Text>
                    </View>
                    <View style={styles.assignmentDetailItem}>
                      <Ionicons name="document" size={14} color="#666" />
                      <Text style={styles.assignmentDetailText}>{assignment.submissionType || 'file'}</Text>
                    </View>
                  </View>
                  
                  <View style={styles.assignmentProgress}>
                    <View style={styles.progressBar}>
                      <View 
                        style={[
                          styles.progressFill,
                          { width: `${(submissionCount / (courseStudents || 1)) * 100}%` }
                        ]}
                      />
                    </View>
                    <Text style={styles.progressText}>
                      {submissionCount} submissions ({gradedCount} graded) of {courseStudents} students
                    </Text>
                  </View>
                  
                  <View style={styles.assignmentActionsRow}>
                    <TouchableOpacity style={styles.assignmentAction}>
                      <Ionicons name="eye" size={16} color="#4dc3ff" />
                      <Text style={styles.assignmentActionText}>View Submissions</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.assignmentAction}>
                      <Ionicons name="stats-chart" size={16} color="#33cc33" />
                      <Text style={styles.assignmentActionText}>Analytics</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.assignmentAction}>
                      <Ionicons name="notifications" size={16} color="#ff9966" />
                      <Text style={styles.assignmentActionText}>Remind</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            }}
          />
        )}
      </View>
    );
  };

  const renderStudentsTab = () => (
    <View style={styles.teacherContent}>
      {showSearch && (
        <View style={styles.searchContainerTeacher}>
          <View style={styles.searchInputContainer}>
            <Ionicons name="search" size={20} color="#999" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search students..."
              placeholderTextColor="#999"
              value={searchText}
              onChangeText={setSearchText}
              autoFocus
            />
            <TouchableOpacity onPress={() => {
              setSearchText('');
              setShowSearch(false);
            }}>
              <Ionicons name="close" size={20} color="#999" />
            </TouchableOpacity>
          </View>
        </View>
      )}
      
      <View style={styles.sectionHeaderWithActionsTeacher}>
        <Text style={styles.sectionTitle}>Students ({filteredData().length})</Text>
        <View style={styles.headerActionsRight}>
          <TouchableOpacity 
            style={styles.headerActionButton}
            onPress={() => setShowSearch(!showSearch)}
          >
            <Ionicons name="search" size={20} color="#666" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.addButtonLarge}
            onPress={() => { setModalType('student'); setShowModal(true); }}
          >
            <Ionicons name="add" size={20} color="white" />
            <Text style={styles.addButtonText}>Add Student</Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {filteredData().length === 0 ? (
        <View style={styles.emptyStateCardTeacher}>
          <Ionicons name="people" size={60} color="#ddd" />
          <Text style={styles.emptyStateText}>No students registered</Text>
          <Text style={styles.emptyStateSubtext}>Add your first student</Text>
          <TouchableOpacity 
            style={styles.emptyStateButton}
            onPress={() => { setModalType('student'); setShowModal(true); }}
          >
            <Text style={styles.emptyStateButtonText}>Add Student</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={filteredData()}
          keyExtractor={item => item.id || Math.random().toString()}
          showsVerticalScrollIndicator={false}
          renderItem={({ item: student }) => {
            const studentCourses = courses.filter(c => student.courses?.includes(c.code));
            const studentAttendance = attendance.filter(a => a.studentId === student.id);
            const attendanceRate = studentAttendance.length > 0 
              ? ((studentAttendance.filter(a => a.status === 'Present').length / studentAttendance.length) * 100).toFixed(1)
              : 0;
            
            return (
              <View style={styles.studentManagementCard}>
                <View style={styles.studentManagementHeader}>
                  <View style={styles.studentAvatar}>
                    <Text style={styles.studentAvatarText}>
                      {student.name?.charAt(0) || 'S'}
                    </Text>
                  </View>
                  <View style={styles.studentManagementInfo}>
                    <Text style={styles.studentManagementName}>{student.name || 'Student'}</Text>
                    <Text style={styles.studentManagementId}>{student.id || 'No ID'}</Text>
                    <Text style={styles.studentManagementEmail}>{student.email || 'No email'}</Text>
                  </View>
                  <View style={styles.studentActions}>
                    <TouchableOpacity style={styles.actionButtonSmall}>
                      <Ionicons name="create" size={16} color="#4dc3ff" />
                    </TouchableOpacity>
                    <TouchableOpacity 
                      style={styles.actionButtonSmall}
                      onPress={() => handleDelete('students', student.id, student.name)}
                    >
                      <Ionicons name="trash" size={16} color="#ff6666" />
                    </TouchableOpacity>
                  </View>
                </View>
                
                <View style={styles.studentDetails}>
                  <View style={styles.studentDetailItem}>
                    <Ionicons name="call" size={14} color="#666" />
                    <Text style={styles.studentDetailText}>{student.phone || 'No phone'}</Text>
                  </View>
                  <View style={styles.studentDetailItem}>
                    <Ionicons name="school" size={14} color="#666" />
                    <Text style={styles.studentDetailText}>Sem {student.semester || 'N/A'}</Text>
                  </View>
                  <View style={styles.studentDetailItem}>
                    <Ionicons name="business" size={14} color="#666" />
                    <Text style={styles.studentDetailText}>{student.department || 'No dept'}</Text>
                  </View>
                </View>
                
                <View style={styles.studentStats}>
                  <View style={styles.studentStatCard}>
                    <Ionicons name="book" size={14} color="#4dc3ff" />
                    <Text style={styles.studentStatValue}>{studentCourses.length}</Text>
                    <Text style={styles.studentStatLabel}>Courses</Text>
                  </View>
                  <View style={styles.studentStatCard}>
                    <Ionicons name="calendar" size={14} color="#33cc33" />
                    <Text style={styles.studentStatValue}>{attendanceRate}%</Text>
                    <Text style={styles.studentStatLabel}>Attendance</Text>
                  </View>
                  <View style={styles.studentStatCard}>
                    <Ionicons name="stats-chart" size={14} color="#ff9966" />
                    <Text style={styles.studentStatValue}>-</Text>
                    <Text style={styles.studentStatLabel}>GPA</Text>
                  </View>
                </View>
                
                <View style={styles.studentManagementActions}>
                  <TouchableOpacity style={styles.studentActionButton}>
                    <Ionicons name="eye" size={14} color="#666" />
                    <Text style={styles.studentActionText}>Profile</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.studentActionButton}
                    onPress={() => {
                      setModalType('attendance');
                      setNewAttendance({
                        ...newAttendance,
                        studentId: student.id,
                        studentName: student.name
                      });
                      setShowModal(true);
                    }}
                  >
                    <Ionicons name="calendar" size={14} color="#666" />
                    <Text style={styles.studentActionText}>Attendance</Text>
                  </TouchableOpacity>
                  <TouchableOpacity 
                    style={styles.studentActionButton}
                    onPress={() => {
                      setModalType('result');
                      setNewResult({
                        ...newResult,
                        studentId: student.id,
                        studentName: student.name
                      });
                      setShowModal(true);
                    }}
                  >
                    <Ionicons name="trophy" size={14} color="#666" />
                    <Text style={styles.studentActionText}>Results</Text>
                  </TouchableOpacity>
                </View>
              </View>
            );
          }}
        />
      )}
    </View>
  );

  const renderContent = () => {
    if (loading && !refreshing) {
      return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#ff6b93" />
          <Text style={styles.loadingText}>Loading dashboard...</Text>
        </View>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return renderDashboard();
      case 'courses':
        return renderCourses();
      case 'materials':
        return renderMaterialsTab();
      case 'assignments':
        return renderAssignmentsTab();
      case 'students':
        return renderStudentsTab();
      default:
        return renderDashboard();
    }
  };

  const getTabIcon = (tab) => {
    switch (tab) {
      case 'dashboard': return 'grid';
      case 'courses': return 'book';
      case 'materials': return 'document';
      case 'assignments': return 'create';
      case 'students': return 'people';
      default: return 'grid';
    }
  };

  const getTabLabel = (tab) => {
    switch (tab) {
      case 'dashboard': return 'Dashboard';
      case 'courses': return 'Courses';
      case 'materials': return 'Materials';
      case 'assignments': return 'Assignments';
      case 'students': return 'Students';
      default: return 'Dashboard';
    }
  };

  return (
    <SafeAreaView style={styles.teacherPortal}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <View style={styles.teacherHeader}>
        <View style={styles.teacherHeaderInfo}>
          <View style={styles.teacherAvatar}>
            <Text style={styles.teacherAvatarText}>{currentUser?.avatar || '👨‍🏫'}</Text>
          </View>
          <View style={styles.teacherHeaderText}>
            <Text style={styles.teacherHeaderName}>{currentUser?.name}</Text>
            <Text style={styles.teacherHeaderRole}>Teacher • {currentUser?.department}</Text>
          </View>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity 
            style={styles.headerActionButton} 
            onPress={() => setShowSearch(!showSearch)}
          >
            <Ionicons name="search" size={22} color="#666" />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.headerActionButton} 
            onPress={() => setShowNotifications(true)}
          >
            <Ionicons name="notifications" size={22} color="#666" />
            {notifications.some(n => !n.read) && (
              <View style={styles.notificationIndicator} />
            )}
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerActionButton} onPress={onLogout}>
            <Ionicons name="log-out" size={22} color="#ff6b93" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.teacherTabs}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {['dashboard', 'courses', 'materials', 'assignments', 'students'].map(tab => (
            <TouchableOpacity 
              key={tab}
              style={[styles.teacherTab, activeTab === tab && styles.teacherTabActive]}
              onPress={() => {
                setActiveTab(tab);
                setShowSearch(false);
                setSearchText('');
              }}
            >
              <Ionicons 
                name={getTabIcon(tab)} 
                size={18} 
                color={activeTab === tab ? '#ff6b93' : '#666'} 
                style={styles.tabIcon}
              />
              <Text style={[styles.teacherTabText, activeTab === tab && styles.teacherTabTextActive]}>
                {getTabLabel(tab)}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      
      <View style={styles.teacherContentContainer}>
        {renderContent()}
      </View>
      
      <TouchableOpacity 
        style={styles.floatingActionButton}
        onPress={() => {
          const actions = [
            { label: 'Course', value: 'course' },
            { label: 'Material', value: 'material' },
            { label: 'Assignment', value: 'assignment' },
            { label: 'Announcement', value: 'announcement' },
            { label: 'Attendance', value: 'attendance' },
            { label: 'Result', value: 'result' },
            { label: 'Student', value: 'student' },
            { label: 'Notification', value: 'notification' }
          ];
          
          Alert.alert(
            'Create New',
            'What would you like to create?',
            actions.map(action => ({
              text: action.label,
              onPress: () => { setModalType(action.value); setShowModal(true); }
            })),
            { cancelable: true }
          );
        }}
      >
        <Ionicons name="add" size={28} color="white" />
      </TouchableOpacity>
      
      {renderModal()}
      
      <NotificationsModal
        visible={showNotifications}
        notifications={notifications}
        onClose={() => setShowNotifications(false)}
        onDeleteAll={handleDeleteAllNotifications} // ✅ Change to this
      />
    </SafeAreaView>
  );
};

// ==============================================
// ✅ MAIN APP COMPONENT
// ==============================================
export default function App() {
  const [currentView, setCurrentView] = useState('welcome');
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { 
          text: 'Cancel', 
          style: 'cancel',
        },
        { 
          text: 'Logout', 
          onPress: () => {
            setCurrentView('welcome');
            setCurrentUser(null);
          }
        }
      ],
      { cancelable: false }
    );
  };

  const renderContent = () => {
    if (isLoading) {
      return (
        <View style={styles.fullScreenLoading}>
          <ActivityIndicator size="large" color="#ff6b93" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      );
    }

    switch (currentView) {
      case 'welcome':
        return (
          <WelcomeScreen
            onStudentAccess={() => setCurrentView('student')}
            onTeacherLogin={() => setCurrentView('teacherLogin')}
          />
        );
      case 'teacherLogin':
        return (
          <TeacherLoginScreen
            onBack={() => setCurrentView('welcome')}
            onLoginSuccess={(user) => {
              setCurrentUser(user);
              setCurrentView('teacher');
            }}
          />
        );
      case 'student':
        return <StudentPortal onBack={() => setCurrentView('welcome')} />;
      case 'teacher':
        return (
          <TeacherPortal 
            onLogout={handleLogout}
            currentUser={currentUser}
          />
        );
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardAvoid}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        {renderContent()}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ==============================================
// ✅ STYLES (Keep your existing styles)
// ==============================================
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  keyboardAvoid: {
    flex: 1,
  },
  
  // Loading Screens
  fullScreenLoading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingScreen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff9fb',
  },
  loadingText: {
    marginTop: 20,
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  
  // Welcome Screen
  welcomeContainer: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  welcomeBackground: {
    flex: 1,
    backgroundColor: '#fff9fb',
  },
  welcomeOverlay: {
    flex: 1,
    justifyContent: 'center',
    padding: 30,
  },
  welcomeContent: {
    alignItems: 'center',
    width: '100%',
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 50,
  },
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#ff6b93',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  welcomeTitle: {
    fontSize: 36,
    color: '#333',
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 40,
  },
  welcomeButtons: {
    width: '100%',
    gap: 20,
    marginBottom: 40,
  },
  welcomeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.1,
    shadowRadius: 15,
    elevation: 5,
  },
  studentButton: {
    backgroundColor: '#4dc3ff',
  },
  teacherButton: {
    backgroundColor: '#ff6b93',
  },
  buttonIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  buttonTextContainer: {
    flex: 1,
  },
  welcomeButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  welcomeButtonSubtext: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
  },
  welcomeFeatures: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 30,
  },
  featureItem: {
    alignItems: 'center',
    flex: 1,
  },
  featureText: {
    fontSize: 12,
    color: '#666',
    marginTop: 8,
    textAlign: 'center',
  },
  
  // Login Screen
  loginContainerWrapper: {
    flex: 1,
    backgroundColor: '#fff',
  },
  loginScrollContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  loginHeader: {
    padding: 30,
    paddingBottom: 20,
    backgroundColor: '#fff9fb',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  backButtonTop: {
    alignSelf: 'flex-start',
    marginBottom: 30,
    padding: 8,
  },
  loginTitleContainer: {
    alignItems: 'center',
  },
  loginIconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#ff6b93',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 15,
    elevation: 8,
  },
  loginTitle: {
    fontSize: 32,
    color: '#333',
    fontWeight: '700',
    marginBottom: 8,
  },
  loginSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  loginForm: {
    padding: 30,
    paddingTop: 20,
  },
  inputGroup: {
    marginBottom: 25,
  },
  inputLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
    fontWeight: '600',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    borderRadius: 15,
    paddingHorizontal: 20,
    borderWidth: 1,
    borderColor: '#e9ecef',
    height: 56,
  },
  inputIcon: {
    marginRight: 15,
  },
  loginInput: {
    flex: 1,
    color: '#333',
    fontSize: 16,
    height: '100%',
  },
  loginOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
  },
  rememberMeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  rememberMeText: {
    fontSize: 14,
    color: '#666',
  },
 
  loginButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ff6b93',
    paddingVertical: 18,
    borderRadius: 15,
    marginBottom: 30,
    shadowColor: '#ff6b93',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 15,
    elevation: 8,
    gap: 10,
  },
  loginButtonDisabled: {
    opacity: 0.7,
  },
  loginButtonIcon: {
    marginRight: 8,
  },
  loginButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '700',
  },
  loginDivider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 30,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e9ecef',
  },
  
  
  // Student Portal
  studentPortal: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  studentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  backButton: {
    padding: 8,
  },
  studentInfo: {
    flex: 1,
    marginLeft: 15,
  },
  studentName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  studentRole: {
    fontSize: 12,
    color: '#666',
  },
  headerActionButton: {
    padding: 8,
    position: 'relative',
  },
  notificationBadge: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: '#ff4757',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 5,
  },
  notificationBadgeText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
  },
  studentTabs: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  studentTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    gap: 8,
  },
  studentTabActive: {
    borderBottomWidth: 2,
    borderBottomColor: '#ff6b93',
  },
  studentTabText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  studentTabTextActive: {
    color: '#ff6b93',
  },
  studentContent: {
    flex: 1,
  },
  
  // Student Dashboard
  welcomeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    margin: 20,
    padding: 25,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  welcomeText: {
    fontSize: 22,
    fontWeight: '700',
    color: '#333',
    marginBottom: 5,
  },
  welcomeSubtext: {
    fontSize: 14,
    color: '#666',
  },
  avatarContainer: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#ffe6ee',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 30,
  },
  statsGridDashboard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 15,
    gap: 15,
    marginBottom: 20,
  },
  statCardDashboard: {
    flex: 1,
    minWidth: (width - 60) / 2,
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  statCard1: {
    borderTopWidth: 4,
    borderTopColor: '#4dc3ff',
  },
  statCard2: {
    borderTopWidth: 4,
    borderTopColor: '#33cc33',
  },
  statCard3: {
    borderTopWidth: 4,
    borderTopColor: '#ff9966',
  },
  statCard4: {
    borderTopWidth: 4,
    borderTopColor: '#ff6b93',
  },
  statNumberDashboard: {
    fontSize: 28,
    fontWeight: '800',
    color: '#333',
    marginVertical: 10,
  },
  statLabelDashboard: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  quickActions: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  actionButtonsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
  },
  quickActionButton: {
    alignItems: 'center',
    flex: 1,
  },
  quickActionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  quickActionText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  seeAllText: {
    fontSize: 14,
    color: '#ff6b93',
    fontWeight: '600',
  },
  recentCourses: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginBottom: 20,
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  recentCourseCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
  },
  recentCourseIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  recentCourseIconText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  recentCourseInfo: {
    flex: 1,
  },
  recentCourseTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  recentCourseName: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  recentCourseTeacher: {
    fontSize: 11,
    color: '#999',
  },
  upcomingAssignments: {
    backgroundColor: '#fff',
    marginHorizontal: 15,
    marginBottom: 30,
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  assignmentReminderCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff9f9',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ffe6e6',
  },
  assignmentReminderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ffe6e6',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  assignmentReminderInfo: {
    flex: 1,
  },
  assignmentReminderTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  assignmentReminderCourse: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  assignmentReminderDue: {
    fontSize: 11,
    color: '#ff6666',
    fontWeight: '600',
  },
  reminderActionButton: {
    backgroundColor: '#ff6b93',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 10,
  },
  reminderActionText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  
  // Courses List
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
    gap: 10,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    borderRadius: 12,
    paddingHorizontal: 15,
    height: 45,
  },
  searchInput: {
    flex: 1,
    color: '#333',
    fontSize: 14,
    marginLeft: 10,
  },
  filterBtn: {
    width: 45,
    height: 45,
    borderRadius: 12,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e9ecef',
    justifyContent: 'center',
    alignItems: 'center',
  },
  coursesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
  },
  sortButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  sortBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#e9ecef',
  },
  sortBtnText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  courseListItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    marginHorizontal: 20,
    marginBottom: 10,
    padding: 15,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  courseListItemIcon: {
    width: 45,
    height: 45,
    borderRadius: 22.5,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  courseListItemIconText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  courseListItemInfo: {
    flex: 1,
  },
  courseListItemCode: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  courseListItemName: {
    fontSize: 13,
    color: '#666',
    marginBottom: 8,
  },
  courseListItemMeta: {
    flexDirection: 'row',
    gap: 15,
  },
  courseMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  courseMetaText: {
    fontSize: 11,
    color: '#666',
  },
  courseListItemStats: {
    flexDirection: 'row',
    gap: 10,
  },
  courseStatItem: {
    alignItems: 'center',
  },
  courseStatText: {
    fontSize: 11,
    color: '#666',
    marginTop: 2,
  },
  emptyListContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 50,
  },
  emptyListText: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
    marginBottom: 10,
  },
  emptyListSubtext: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  
  // Course Details Page
  courseDetailsContainer: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  courseDetailsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  courseDetailsHeaderCenter: {
    flex: 1,
    alignItems: 'center',
  },
  courseDetailsHeaderTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  courseDetailsHeaderSubtitle: {
    fontSize: 12,
    color: '#666',
  },
  courseTabs: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  courseTab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 15,
  },
  courseTabActive: {
    position: 'relative',
  },
  courseTabText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  courseTabTextActive: {
    color: '#ff6b93',
  },
  tabIndicator: {
    position: 'absolute',
    bottom: 0,
    width: '60%',
    height: 3,
    backgroundColor: '#ff6b93',
    borderTopLeftRadius: 3,
    borderTopRightRadius: 3,
  },
  courseContent: {
    flex: 1,
    padding: 20,
  },
  
  // Course Overview
  courseInfoCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  courseHeaderInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 25,
  },
  courseCodeCircle: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 20,
  },



notificationUnread: {
  backgroundColor: '#ffe6ee',
},
notificationTitleUnread: {
  color: '#333',
  fontWeight: '700',
},
unreadDot: {
  width: 8,
  height: 8,
  borderRadius: 4,
  backgroundColor: '#ff6b93',
},
deleteAllButton: {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 12,
  borderRadius: 10,
  backgroundColor: '#ffe6e6',
  borderWidth: 1,
  borderColor: '#ffcccc',
  gap: 8,
  marginTop: 10,
},
deleteAllText: {
  fontSize: 14,
  color: '#ff4757',
  fontWeight: '600',
},
notificationMeta: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginTop: 5,
},
notificationType: {
  fontSize: 11,
  color: '#999',
  backgroundColor: '#f0f0f0',
  paddingHorizontal: 6,
  paddingVertical: 2,
  borderRadius: 4,
},
notificationTime: {
  fontSize: 11,
  color: '#999',
},








  courseCodeChar: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  courseTitleContainer: {
    flex: 1,
  },
  courseDetailName: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
    marginBottom: 4,
  },
  courseDetailCode: {
    fontSize: 14,
    color: '#666',
  },
  courseStats: {
    backgroundColor: '#f8f9fa',
    borderRadius: 15,
    padding: 20,
    marginBottom: 25,
  },
  statItemDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  statItemDetailContent: {
    marginLeft: 12,
  },
  statLabelDetail: {
    fontSize: 12,
    color: '#999',
    marginBottom: 2,
  },
  statValueDetail: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
  },
  courseDescriptionSection: {
    marginBottom: 25,
  },
  courseDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
  },
  learningOutcomes: {
    marginBottom: 20,
  },
  outcomeItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    gap: 10,
  },
  outcomeText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
    lineHeight: 20,
  },
  noDataText: {
    fontSize: 14,
    color: '#999',
    fontStyle: 'italic',
  },
  
  // Materials View
  sectionHeaderWithActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  filterButtonsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  filterButtonStyle: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#e9ecef',
  },
  filterButtonActive: {
    backgroundColor: '#ffe6ee',
    borderColor: '#ff6b93',
  },
  filterButtonTextStyle: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  viewAllButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: '#f8f9fa',
  },
  viewAllButtonText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  emptyStateCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 40,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#666',
    marginTop: 20,
    marginBottom: 10,
    fontWeight: '600',
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
    lineHeight: 20,
  },
  materialCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  materialIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  materialInfo: {
    flex: 1,
  },
  materialCardTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 4,
  },
  materialCardDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 8,
    lineHeight: 16,
  },
  materialMeta: {
    flexDirection: 'row',
    gap: 15,
  },
  materialType: {
    fontSize: 11,
    color: '#999',
  },
  materialDate: {
    fontSize: 11,
    color: '#999',
  },
  materialSize: {
    fontSize: 11,
    color: '#999',
  },
  downloadButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#e6f7ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  // Assignments View
  assignmentCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  assignmentCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  assignmentStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff9f0',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    gap: 5,
  },
  assignmentStatusText: {
    fontSize: 11,
    color: '#ff9966',
    fontWeight: '600',
  },
  assignmentDueDate: {
    fontSize: 11,
    color: '#ff6666',
    fontWeight: '600',
  },
  assignmentCardTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 8,
  },
  assignmentCardDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 15,
    lineHeight: 18,
  },
  assignmentFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  assignmentPoints: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  assignmentPointsText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ff6b93',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 10,
    gap: 5,
  },
  submitButtonDisabled: {
    backgroundColor: '#cccccc',
  },
  submitButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  
  // Announcements View
  announcementCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  announcementHeader: {
    flexDirection: 'row',
    marginBottom: 15,
  },
  announcementIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ffe6ee',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  announcementInfo: {
    flex: 1,
  },
  announcementTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  announcementMeta: {
    fontSize: 11,
    color: '#999',
  },
  announcementContent: {
    fontSize: 13,
    color: '#666',
    lineHeight: 20,
    marginBottom: 15,
  },
  announcementAttachments: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  attachmentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    gap: 5,
  },
  attachmentText: {
    fontSize: 11,
    color: '#666',
  },
  
  // Material Modal
  fullModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  fullModalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    maxHeight: height * 0.9,
  },
  fullModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  fullModalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  fullModalBody: {
    padding: 20,
    maxHeight: height * 0.7,
  },
  fullModalBodyContent: {
    paddingBottom: 20,
  },
  fullModalFooter: {
    flexDirection: 'row',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#e9ecef',
    gap: 15,
  },
  cancelButtonLarge: {
    flex: 1,
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#e9ecef',
  },
  cancelButtonTextLarge: {
    color: '#666',
    fontSize: 14,
    fontWeight: '600',
  },
  confirmButtonLarge: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 15,
    borderRadius: 12,
    backgroundColor: '#ff6b93',
    gap: 8,
  },
  confirmButtonTextLarge: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  materialDetailHeader: {
    alignItems: 'center',
    marginBottom: 30,
  },
  materialDetailIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  materialDetailTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  materialDetailType: {
    fontSize: 14,
    color: '#666',
  },
  materialDetailSection: {
    marginBottom: 25,
  },
  detailSectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginBottom: 15,
  },
  materialDetailDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
  },
  detailGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
  },
  detailItemCard: {
    flex: 1,
    minWidth: (width - 70) / 2,
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  detailItemLabel: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
    marginBottom: 4,
  },
  detailItemValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '600',
  },
  actionButtonLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4dc3ff',
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    gap: 10,
  },
  actionButtonSecondary: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#4dc3ff',
  },
  actionButtonTextLarge: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  actionButtonTextSecondary: {
    color: '#4dc3ff',
  },
  
  // Teacher Portal
  teacherPortal: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  teacherHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  teacherHeaderInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
    flex: 1,
  },
  teacherAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#ffe6ee',
    justifyContent: 'center',
    alignItems: 'center',
  },
  teacherAvatarText: {
    fontSize: 24,
  },
  teacherHeaderText: {
    flex: 1,
  },
  teacherHeaderName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  teacherHeaderRole: {
    fontSize: 12,
    color: '#666',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  notificationIndicator: {
    position: 'absolute',
    top: 2,
    right: 2,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ff4757',
  },
  teacherTabs: {
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  teacherTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  teacherTabActive: {
    borderBottomWidth: 2,
    borderBottomColor: '#ff6b93',
  },
  teacherTabText: {
    fontSize: 13,
    color: '#666',
    fontWeight: '600',
  },
  teacherTabTextActive: {
    color: '#ff6b93',
  },
  tabIcon: {
    marginRight: 8,
  },
  teacherContentContainer: {
    flex: 1,
  },
  teacherContent: {
    flex: 1,
    padding: 20,
  },
  floatingActionButton: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#ff6b93',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 15,
    elevation: 10,
  },
  
  // Teacher Dashboard
  teacherWelcomeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 25,
    borderRadius: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
  },
  teacherWelcomeText: {
    fontSize: 22,
    fontWeight: '700',
    color: '#333',
    marginBottom: 5,
  },
  teacherWelcomeSubtext: {
    fontSize: 14,
    color: '#666',
  },
  profileButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#ffe6ee',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileText: {
    fontSize: 28,
  },
  statsGridTeacher: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
    marginBottom: 20,
  },
  statCardTeacher: {
    flex: 1,
    minWidth: (width - 70) / 2,
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  statNumberTeacher: {
    fontSize: 32,
    fontWeight: '800',
    color: '#333',
    marginVertical: 10,
  },
  statLabelTeacher: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  quickActionsDashboard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  actionGridDashboard: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 15,
    marginTop: 15,
  },
  actionCard: {
    flex: 1,
    minWidth: (width - 70) / 2,
    backgroundColor: '#f8f9fa',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
  },
  actionIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },
  actionIcon1: {
    backgroundColor: '#4dc3ff',
  },
  actionIcon2: {
    backgroundColor: '#33cc33',
  },
  actionIcon3: {
    backgroundColor: '#ff9966',
  },
  actionIcon4: {
    backgroundColor: '#ff6b93',
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 5,
    textAlign: 'center',
  },
  actionDescription: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  recentActivity: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  activityList: {
    marginTop: 15,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  activityIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  activityInfo: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 2,
  },
  activityDescription: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 11,
    color: '#999',
  },
  upcomingDeadlines: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  deadlineCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
  },
  deadlineIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#fff9f0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  deadlineInfo: {
    flex: 1,
  },
  deadlineTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  deadlineCourse: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  deadlineDue: {
    fontSize: 11,
    color: '#ff6666',
    fontWeight: '600',
  },
  deadlineStats: {
    alignItems: 'flex-end',
  },
  deadlineStatText: {
    fontSize: 11,
    color: '#666',
    fontWeight: '600',
  },
  
  // Notifications Modal
  notificationsModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'flex-end',
  },
  notificationsModalContent: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    maxHeight: height * 0.8,
  },
  notificationsModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e9ecef',
  },
  notificationsModalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
  },
  notificationsList: {
    padding: 20,
    maxHeight: height * 0.6,
  },
  emptyNotifications: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyNotificationsText: {
    fontSize: 18,
    color: '#666',
    marginTop: 20,
    marginBottom: 10,
    fontWeight: '600',
  },
  emptyNotificationsSubtext: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  notificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    borderRadius: 15,
    marginBottom: 10,
    backgroundColor: '#f8f9fa',
  },
  notificationUnread: {
    backgroundColor: '#ffe6ee',
  },
  notificationIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  notificationContent: {
    flex: 1,
  },
  notificationTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginBottom: 4,
  },
  notificationTitleUnread: {
    color: '#333',
    fontWeight: '700',
  },
  notificationMessage: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  notificationTime: {
    fontSize: 11,
    color: '#999',
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#ff6b93',
  },
  notificationsModalFooter: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#e9ecef',
  },
  markAllReadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 10,
    backgroundColor: '#f8f9fa',
    gap: 8,
  },
  markAllReadText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  
  // Teacher Modals
  modalRow: {
    flexDirection: 'row',
    gap: 15,
    marginBottom: 15,
  },
  modalColumn: {
    flex: 1,
  },
  modalLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
    marginTop: 5,
  },
  modalInput: {
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#e9ecef',
    borderRadius: 12,
    padding: 15,
    color: '#333',
    fontSize: 14,
    marginBottom: 15,
  },
  textArea: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  courseListContainer: {
    maxHeight: 150,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#e9ecef',
    borderRadius: 12,
    padding: 10,
  },
  courseOption: {
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e9ecef',
    marginBottom: 8,
  },
  courseOptionSelected: {
    backgroundColor: '#ffe6ee',
    borderColor: '#ff6b93',
  },
  courseOptionText: {
    fontSize: 14,
    color: '#666',
  },
  courseOptionTextSelected: {
    color: '#ff6b93',
    fontWeight: '600',
  },
  typeScroll: {
    marginBottom: 15,
  },
  typeSelection: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 15,
  },
  typeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e9ecef',
    gap: 8,
    minWidth: 100,
  },
  typeOptionSelected: {
    backgroundColor: '#ffe6ee',
    borderColor: '#ff6b93',
  },
  typeOptionText: {
    fontSize: 13,
    color: '#666',
  },
  typeOptionTextSelected: {
    color: '#ff6b93',
    fontWeight: '600',
  },
  addAttachmentButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e9ecef',
    gap: 10,
  },
  addAttachmentText: {
    fontSize: 14,
    color: '#4dc3ff',
    fontWeight: '600',
  },
  
  // Teacher Courses Management
  sectionHeaderWithActionsTeacher: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerActionsRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 15,
  },
  addButtonLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ff6b93',
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 12,
    gap: 8,
  },
  addButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyStateCardTeacher: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 40,
    alignItems: 'center',
    marginTop: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  emptyStateButton: {
    backgroundColor: '#ff6b93',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 12,
    marginTop: 20,
  },
  emptyStateButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  courseManagementCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  courseManagementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  courseCodeCircleLarge: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#ff6b93',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  courseCodeCharLarge: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  courseManagementInfo: {
    flex: 1,
  },
  courseManagementCode: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  courseManagementName: {
    fontSize: 14,
    color: '#666',
    marginBottom: 2,
  },
  courseManagementTeacher: {
    fontSize: 12,
    color: '#999',
  },
  courseActions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButtonSmall: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
  },
  courseManagementDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    marginBottom: 20,
  },
  courseManagementStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  courseStatCard: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 12,
    marginHorizontal: 5,
  },
  courseStatValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
    marginVertical: 5,
  },
  courseStatLabel: {
    fontSize: 11,
    color: '#666',
    fontWeight: '600',
  },
  courseManagementActions: {
    flexDirection: 'row',
    gap: 10,
  },
  courseActionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 10,
    gap: 8,
  },
  courseActionText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  
  // Teacher Materials Management
  searchContainerTeacher: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
    marginBottom: 20,
  },
  materialsFilter: {
    flexDirection: 'row',
    gap: 15,
    marginBottom: 20,
  },
  searchInputSmall: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#e9ecef',
    borderRadius: 12,
    padding: 12,
    color: '#333',
    fontSize: 14,
  },
  filterButtonSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    paddingHorizontal: 15,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#e9ecef',
    gap: 8,
  },
  filterButtonSmallText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
  },
  materialManagementCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  materialHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  materialTypeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
    gap: 6,
  },
  materialTypeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  materialActions: {
    flexDirection: 'row',
    gap: 10,
  },
  materialActionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
  },
  materialManagementTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginBottom: 10,
  },
  materialManagementDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    marginBottom: 15,
  },
  materialDetails: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 15,
  },
  materialDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  materialDetailText: {
    fontSize: 12,
    color: '#666',
  },
  materialLinkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e6f7ff',
    padding: 12,
    borderRadius: 10,
    gap: 10,
    marginBottom: 15,
  },
  materialLinkText: {
    fontSize: 14,
    color: '#4dc3ff',
    fontWeight: '600',
  },
  materialStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  materialStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  materialStatText: {
    fontSize: 12,
    color: '#999',
  },
  
  // Teacher Assignments Management
  assignmentManagementCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  assignmentManagementHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 15,
  },
  assignmentManagementTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginBottom: 5,
  },
  assignmentCourse: {
    fontSize: 12,
    color: '#666',
  },
  assignmentActions: {
    flexDirection: 'row',
    gap: 10,
  },
  assignmentActionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
  },
  assignmentManagementDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    marginBottom: 15,
  },
  assignmentDetails: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 15,
  },
  assignmentDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  assignmentDetailText: {
    fontSize: 12,
    color: '#666',
  },
  assignmentProgress: {
    marginBottom: 15,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#f8f9fa',
    borderRadius: 3,
    marginBottom: 8,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#4dc3ff',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: '#666',
  },
  assignmentActionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  assignmentAction: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    padding: 10,
  },
  assignmentActionText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  
  // Teacher Students Management
  studentManagementCard: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 20,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  studentManagementHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  studentAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#4dc3ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  studentAvatarText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  studentManagementInfo: {
    flex: 1,
  },
  studentManagementName: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginBottom: 2,
  },
  studentManagementId: {
    fontSize: 12,
    color: '#666',
    marginBottom: 2,
  },
  studentManagementEmail: {
    fontSize: 12,
    color: '#666',
  },
  studentActions: {
    flexDirection: 'row',
    gap: 10,
  },
  studentDetails: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 15,
  },
  studentDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  studentDetailText: {
    fontSize: 12,
    color: '#666',
  },
  studentStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  studentStatCard: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
    padding: 15,
    borderRadius: 12,
    marginHorizontal: 5,
  },
  studentStatValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginVertical: 5,
  },
  studentStatLabel: {
    fontSize: 11,
    color: '#666',
    fontWeight: '600',
  },
  studentManagementActions: {
    flexDirection: 'row',
    gap: 10,
  },
  studentActionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 10,
    gap: 8,
  },
  studentActionText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
});